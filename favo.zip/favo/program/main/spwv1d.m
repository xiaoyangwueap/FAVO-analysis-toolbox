function [tfrx,t,f]=spwv1d(x, dt, winT, winF);
%  [tfrx,T,F] = spwv1d(x, dt, winT,WinF) computes the spectrum of a 1D 
%  discrete-time signal x using smoothed pseudo Wigner-ville transform.
%
%  input:
%      x: the 1D signal
%      dt: time interval (unit:second)
%      winT: time window points, equal to wavelet length
%      winF: frequency window points, equal to 2*winT
%  
%  output:
%      tfrx: the spectral amplitude of x;
%      t:time series
%      f:frequency series
%
%  Example:
%      infile = 'D:\MATLAB\R2008a\work\favo\data\example1\model.dat';
%      x = load(infile);
%      [tfrx,t,f] = spwv1d(x, 0.001, 30, 60);
%
%  16 Jun 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

if (nargin < 1),
    error('At least 1 parameter is required');
elseif (nargin == 1),
    dt=0.001;winT = 30; winF = 60;
elseif(nargin == 2)
    winT = 30; winF = 60;
elseif(nargin == 3)
    winF = 60;
end

[m1,n1]=size(x);
if(m1 ~= 1 && n1 ~= 1),
    error('x must have only one row or one column,please check!');
end
if (m1 == 1), x=x'; end

N = length(x);
nfft = 2^nextpow2(N);        %nextpow2: returns the first P such that 2^P >= abs(N)
t = (1:N);
sigma1 = 0.18;
sigma2 = 0.36;

k1 = exp(-1/(2*sigma1^2));     %the parameter sigma of Gaussian function
k2 = exp(-1/(2*sigma2^2));

gLength = round(winT/(dt*1e3));
if rem(gLength, 2) == 0
    gLength = gLength+1;
end

hLength = round(winF/(dt*1e3));
if rem(hLength, 2) == 0
    hLength = hLength+1;
end

g = window_m(gLength, 'gauss', k1);
h = window_m(hLength, 'gauss', k2);
%tic  %start timing
[tfrx,t,f] = tfrspwv_m(hilbert(x), dt, g, h);  %smoothed pseudo Wigner-ville transform
%toc  %end timing
figure;
subplot(1,2,1);plot(x,t); 
set(gca,'ydir', 'reverse');
title('Synthetic trace');
ylabel('Time (S)');
ylim([t(1) t(end)]);
subplot(1,2,2);
pcolor(f,t,tfrx);
shading interp;
%shading flat;
colormap(jet);
set(gca,'ydir', 'reverse')
title('Spectrum');
xlabel('Frequency (Hz)');
ylabel('Time (second)')
xlim([0 100]);
%colorbar;
%caxis([0,6]);

tmin=min(t);tmax=max(t);fmin=min(f);fmax=max(f);
path=pwd;
GrdFile=strcat(path,'\favo\data\example1\spwvd.grd');
x=flipud(tfrx);         %flipud(A):turn up and down     fliplr(A):turn left and right     rot90(A):rotate 90 degree
WriteGrd(x,GrdFile,fmin,fmax,tmin,tmax);
 
 