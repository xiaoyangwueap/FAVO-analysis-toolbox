function y = vel_interpolate(infile, ns, dt, start)
%  This function is used to interpolate scattering velocities at un-uniform 
%  interval to uniform interval with linear interpolation.
%
%  input:
%      infile: filename that stores velocity, should be two column, the first 
%              one is time depth, the second one is corresponding velocity
%      ns:num of samples
%      dt:sampling rate
%      start:sampling start time
%
%  output:
%      y: one-dimension array storing the velocity at each sampling
%      position.
%
%  Example:
%       infile = 'D:\MATLAB\R2008a\work\favo\data\example8\IL1605_vel_insert.dat';
%       ns = 750;
%       dt = 4;
%       start = 0;
%       y = vel_interpolate(infile, ns, dt, start);
%
%  3 July 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

if (exist(infile)==0),
    error('the inut file does not exist, please check!');
end
if (nargin == 1),
    ns = 1000; dt = 0.001; start = 0;
elseif(nargin == 2),
    dt = 0.001; start = 0;
elseif(nargin == 3),
    start = 0;
end;

a = load(infile);
[m,n] = size(a);

if (n~=2),
    error('the input infile must have only two columns, please check!');
end

x = zeros(ns,1);    %time
y = zeros(ns,1);    %depth

for i = 1:ns
    x(i) = start + (i-1)*dt;
    for j = 1:m-1
        if x(i) < a(1,1),
           y(i) = a(1,2);
        elseif x(i) >= a(j,1) && x(i)<a(j+1,1),
           y(i) = (a(j+1,2)-a(j,2))/(a(j+1,1)-a(j,1))*(x(i)-a(j,1))+a(j,2);
        elseif x(i) >= a(m,1),
           y(i) = a(m,2);
        end
    end
end

figure,
subplot(1,2,1);plot(a(:,1),a(:,2),'b.');
subplot(1,2,2);plot(x,y,'r.');

file = strcat(pwd,'\favo\data\example8\vel_int.dat');
[fidGrd, msg] = fopen(file,'wt');
for i = 1:ns
    fprintf(fidGrd,'%f  %f',x(i),y(i));
    fprintf(fidGrd,'\n');
end
fclose(fidGrd);

