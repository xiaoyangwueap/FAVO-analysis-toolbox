function [a] = stft3d_layer(infile1,infile2,outfile,ntrace,frq,htype,hlength);
%  [] = stft3d_layer(infile,ntrace,frq,htype,hlength) computes horizontal 
%  layer spectrum of 3D .sgy format seismic data using the short-time Fourier
%  transform. 
%  
%  input:
%      infile1: input .sgy file storing a 3D poststack seismic data
%      infile2: input horizontal time layer for calculation
%      outfile: output file storing the result
%      ntrace: number of traces in .sgy file
%      frq: frequencies for spectral decomposition
%      htype: window type used in STFT
%             htype=0, Hamming window
%             htype=1, Hanning window
%             htype=2, Gaussian window
%             htype=3, Nuttall window
%      hlength: window length
%
% output:
%      a:average spectral amplitude of the layer;
%  
%  Example:
%       infile1='D:\MATLAB\R2008a\work\favo\data\example3\grub3D_stack.sgy';
%       infile2='D:\MATLAB\R2008a\work\favo\data\example3\time3D.dat';
%       outfile='D:\MATLAB\R2008a\work\favo\data\example3\a_stft.dat';
%       stft3d_layer(infile1,infile2,outfile,13870,[30 40 50]);
%  in the example, ntrace=13870;
%
%  17 Jun 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

index1 = exist(infile1,'file');
index2 = exist(infile2,'file');
if (index1 == 0 || index2 == 0),
    error('input files do not exist,please check!');
end

sgy3200=zeros(1600,1, 'uint16');
sgy400=zeros(200,1, 'uint16');
sgyhead = zeros(120,1, 'int16');

fidin=fopen(infile1,'r','ieee-be');
sgy3200=fread(fidin, 1600, 'uint16');
sgy400=fread(fidin, 200, 'uint16');

ns=sgy400(11);
dt=sgy400(9)/1000000;

if (nargin <=3),
    error('At least 4 parameter is required.');
elseif (nargin == 4),
    frq=[10,20,30,40,50]; htype=2; hlength=floor(ns/4);
elseif (nargin == 5),
    htype=2; hlength=floor(ns/4);
elseif (nargin == 6),
    hlength=floor(ns/4);
end;

nfrq=length(frq);         %Number of frequencies
time1=load(infile2);
x=size(time1);
if (x(2)==1),
    time=time1;
elseif (x(2)>1),
    time=time1(:,x(2));
end

tt=floor(time./dt);
w(ns,ntrace,nfrq)=0;
absw(ns,ntrace,nfrq)=0;
f=[0:(ns-1)/2]'/(ns*dt);
t=[0:ns-1]'*dt;
M=length(t);
N=length(f);
w1(M,N)=0;

sgydata=zeros(ns, 1, 'single');
segy_format = sgy400(13);
switch segy_format
    case 1
        sgytrace=zeros(ns, 1, 'uint32');
    case 5
        sgytrace=zeros(ns, 1, 'single');
    otherwise
        return;
end

for i=1:nfrq
    for j=1:N-1
        if (frq(i)>=f(j) && frq(i)<f(j+1))
            NN(i)=j;
            break;
        end
    end
end

for ktrace=1:ntrace
    fseek(fidin , double(3200+400+(ktrace-1)*(ns*4+240)),'bof');
    sgyhead = fread(fidin, 120, 'int16');
        switch segy_format
            case 1
                sgytrace=fread(fidin, ns,'uint32');
                sgydata=single(ibm2ieee(sgytrace) );
            case 5
                sgytrace=fread(fidin, ns,'single');
                sgydata=single(sgytrace);
            otherwise 
        end

    [w1,t1,f1] = tfrstft_m(sgydata,htype,hlength,dt); %Gauss window
    
    for i=1:nfrq
        w(:,ktrace,i)=w1(:,NN(i));
        absw(:,ktrace,i)=abs(w(:,ktrace,i));
        a(ktrace,i)=max(absw(tt(ktrace)-20:tt(ktrace)+20, ktrace,i));
    end
      
    per=ktrace/ntrace*100;
    if(rem(ktrace,2000)==0) 
       per1=num2str(per);
       per2=strcat(per1,'% is calculated!');
       fprintf('%s\n',per2);
    end
end
fclose(fidin);

fid = fopen(outfile,'w');
for i=1:ntrace
    for j=1:nfrq
        fprintf(fid,' %10.3f',a(i,j));
    end
    fprintf(fid,'\n');
end
fclose(fid);