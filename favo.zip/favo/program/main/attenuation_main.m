function qi = attenuation_main(por,f0)
%  This function calculates the variation of 1/Q with water saturation by 
%  calling the subroutine avo_rp.m, which is used to calculate the elastic 
%  constant at a certain frequency using Chapman et al.(2002) model
%  with wood's formula, which is used to calculate the elastic moduli of 
%  mixture.
%
%  input:
%       por: porosity
%       f0: frequency
%
%  output:
%       qi:invere quality factor 1/Q
%
%  Example:
%        f0 = 50;
%        por = 0.10;
%        qi = attenuation_main(por,f0);
%
%  3 July 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

for i = 1:100
    sw(i) = i/100;
    sg(i) = 1-sw(i);
    [lfw(i), mfw(i), r(i)] = avo_rp(f0, sw(i), por);
    qi(i) = imag(lfw(i) + 2 * mfw(i))/real(lfw(i) + 2 * mfw(i));
end

figure, plot(sg,qi,'LineWidth',2);
xlabel('Sw(fractal)');
ylabel('attenuation(1/Q)');

file = strcat(pwd,'\favo\data\Qi',num2str(f0),'.dat');
[fidGrd, msg] = fopen(file,'wt');
for k = 1:100
    fprintf(fidGrd,'%e %e\n',sg(k),qi(k));
end
fclose(fidGrd);
