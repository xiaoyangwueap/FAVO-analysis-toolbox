function [a] = layer_cwt(infile1,infile2,outfile,ntrace,frq);
%  This function computes horizontal layer spectrum of 3D .sgy format 
%  seismic data using the continuous wavelet transform. 
%
%  input:
%      infile1: input .sgy file storing a 3D poststack seismic data
%      infile2: input horizontal time layer for calculation, one column with
%               only t value or three column with x,y,t
%      outfile: output filename storing the result
%      ntrace: number of traces in .sgy file
%      frq: frequencies for spectral decomposition
%  
%  output:
%      a: average spectral amplitude of the layer
%
%  Example:
%       infile1='D:\MATLAB\R2008a\work\ssd\data\grub3D_stack.sgy';
%       infile2='D:\MATLAB\R2008a\work\ssd\data\time3D.dat';
%       outfile='D:\MATLAB\R2008a\work\ssd\data\a_spwv.dat';
%       layer_stft(infile1,infile2,outfile,13870,[20 30 40 50],2,100);
%  in the example, ntrace=13870;
%
%  17 Jun 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

index1 = exist(infile1,'file');
index2 = exist(infile2,'file');
if (index1 == 0 || index2 == 0),
    error('input files do not exist,please check!');
end

if (nargin <= 3),
    error('At least 4 parameter is required.');
elseif (nargin == 4),
    frq = [10,20,30,40];
end;

nfrq = length(frq);         %Number of frequencies
time1 = load(infile2);
x = size(time1);
if (x(2) == 1),
    time = time1;
elseif (x(2) > 1),
    time = time1(:,x(2));
end

sgy3200 = zeros(1600,1, 'uint16');
sgy400 = zeros(200,1, 'uint16');
sgyhead = zeros(120,1, 'int16');

fidin = fopen(infile1,'r','ieee-be');
sgy3200 = fread(fidin, 1600, 'uint16');
sgy400 = fread(fidin, 200, 'uint16');

ns = sgy400(11);
dt = sgy400(9)/1000000;
tt = floor(time./dt);
w(ns,ntrace,nfrq) = 0;
absw(ns,ntrace,nfrq) = 0;
wavelet = 'mmor';

sgydata = zeros(ns, 1, 'single');
segy_format = sgy400(13);
switch segy_format
    case 1
        sgytrace=zeros(ns, 1, 'uint32');
    case 5
        sgytrace=zeros(ns, 1, 'single');
    otherwise
        return;
end

for ktrace = 1:ntrace
    fseek(fidin , double(3200+400+(ktrace-1)*(ns*4+240)),'bof');
    sgyhead = fread(fidin, 120, 'int16');
        switch segy_format
            case 1
                sgytrace = fread(fidin, ns,'uint32');
                sgydata = single(ibm2ieee(sgytrace));
            case 5
                sgytrace = fread(fidin, ns,'single');
                sgydata = single(sgytrace);
            otherwise
        end

    for i = 1:nfrq
        scale = centfrq(wavelet)/(dt*frq(i));
        w1 = cwt(sgydata,scale,wavelet);
        w(:,ktrace,i) = w1(:);
        absw(:,ktrace,i) = abs(w(:,ktrace,i));
        a(ktrace,i) = max(absw(tt(ktrace)-20:tt(ktrace)+20, ktrace,i));
    end
      
    per = ktrace/ntrace*100;
    if(rem(ktrace,2000) == 0)
       per1 = num2str(per);
       per2 = strcat(per1,'% is calculated!');
       fprintf('%s\n',per2);
    end
end
fclose(fidin);

fid = fopen(outfile,'w');
for i = 1:ntrace
    for j = 1:nfrq
        fprintf(fid,' %10.3f',a(i,j));
    end
    fprintf(fid,'\n');
end
fclose(fid);
