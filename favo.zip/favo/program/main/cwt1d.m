function [tcwt,t,f] = cwt1d(x,dt);
%  This function applies the continuous wavelet transform to a 1D discrete
%  time signal x using modified Morlet wavelet.
%
%  Before using this function, make sure the modified morlet wavelet is 
%  added to Matlab. the following scripts can be used to add modmorlet 
%  wavelet to matlab:
%      wavemngr('read',1);    %view existing wavelet;
%      wavemngr('add','Mod Morlet','mmor',4,'','modmorlet',[-4,4]); 
%      ((('operation','full name', 'abbreviation', 'type', 'm file name',
%      'length';)))
%
%  input:
%      x: the 1D signal
%      dt: time interval
%
%  output:
%      tcwt: the spectral amplitudes of x
%      t: time series
%      f: frequency series
%   
%  Example:
%      infile = 'D:\MATLAB\R2008a\work\favo\data\example1\model.dat'; 
%      x = load(infile); 
%      [tcwt,t,f] = cwt1d(x, 0.001);
%
%  16 Jun 2012, Xiaoyang Wu, 
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

if (nargin < 1),
    error('At least 1 parameter is required');
elseif (nargin == 1),
    dt = 0.001;
end

[m1,n1]=size(x);
if(m1 ~= 1 && n1 ~= 1),
    error('x should be one row or one column,please check!');
end
if (m1 == 1), x=x'; end

if (nargin < 1),
    error('At least 1 parameter is required');
elseif (nargin == 1),
    dt = 0.001;
end

N = length(x);
[tfrx,t,f] = tfrstft_m(x);
M = length(f);

for i = 1:M
    f(i) = f(i)+0.1;
    scale(i) = centfrq('mmor')/(dt * f(i));  
end

tcwt = cwt(hilbert(x),scale(:),'mmor');   
tcwt = abs(tcwt);
tcwt = tcwt';

figure;
subplot(1,2,1);plot(x,t); 
set(gca,'ydir', 'reverse');
title('Synthetic trace');
ylabel('Time (S)');
ylim([t(1) t(end)]);

subplot(1,2,2);
pcolor(f,t,tcwt);
shading interp;
colormap(jet);
set(gca,'ydir', 'reverse')
title('spectrum');
xlabel('Frequency (Hz)');
ylabel('Time (second)')
xlim([0 100]);

tmin = min(t);tmax = max(t);fmin = min(f);fmax = max(f);
path = pwd;
GrdFile = strcat(path,'\favo\data\example1\cwt.grd');
tcwt = flipud(tcwt);   %flipud(A):turn up and down     fliplr(A):turn left and right     rot90(A):counterclockwise rotate A 90 degree
WriteGrd(tcwt,GrdFile,fmin,fmax,tmin,tmax);
