function [a] = spwv3d_layer(infile1,infile2,outfile,ntrace,frq,winT,winF);
%  [a] = spwv3d_layer(infile1,infile2,outfile,ntrace,frq,winT,winF) computes
%  horizontal layer spectrum of 3D .sgy format seismic data using the 
%  smoothed pseudo Wigner-Ville transform. The .sgy data can be cut to a 
%  small volumn that only contains the data of the horizontal layer.
%  
%  input:
%      infile1: input .sgy file storing a 3D poststack seismic data
%      infile2: input horizontal time layer for calculation
%      outfile: output file storing the spectral amlitude
%      ntrace: number of traces in .sgy file
%      frq: frequencies for spectral decomposition
%      winT: time smooth window
%      winF: frequenc smooth window
%
%  output:
%  a:average spectral amplitude of the layer;
%
%  Example:
%         infile1='D:\MATLAB\R2008a\work\favo\data\example3\grub3D_stack.sgy';
%         infile2='D:\MATLAB\R2008a\work\favo\data\example3\time3D.dat';
%         outfile='D:\MATLAB\R2008a\work\favo\data\example3\a_spwv.dat';
%         spwv3d_layer(infile1,infile2,outfile,13870,[20 30 40 50]);
%  in the example, ntrace=13870;
%
%  17 Jun 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

index1 = exist(infile1,'file');
index2 = exist(infile2,'file');
if (index1 == 0 || index2 == 0),
    error('input files do not exist,please check!');
end

if (nargin <=3),
    error('At least 4 parameter is required.');
elseif (nargin == 4),
    frq=[10,20,30,40,50]; winT = 30; winF = 60; 
elseif (nargin == 5),
    winT = 30; winF = 60; 
elseif (nargin == 6),
    winF = 60; 
end;

sigma1 = 0.18;
sigma2 = 0.36;
k1 = exp(-1/(2*sigma1^2));
k2 = exp(-1/(2*sigma2^2));

nfrq = length(frq);    %Number of frequencies
time1 = load(infile2);
x = size(time1);
if (x(2) == 1),        %only one column in infile2
    time = time1;
elseif (x(2)>1),       %if there is more than one column in infile2,using the last column
    time = time1(:,x(2));
end

sgy3200 = zeros(1600,1, 'uint16');
sgy400 = zeros(200,1, 'uint16');
sgyhead = zeros(120,1, 'int16');

fidin = fopen(infile1,'r','ieee-be');
sgy3200 = fread(fidin, 1600, 'uint16');
sgy400 = fread(fidin, 200, 'uint16');

ns = sgy400(11);                % num of sample per trace
dt = sgy400(9)/1000000;         % time spacing  unit:second
tt = floor(time./dt);           % unit:second
%tt=floor(time./dt)./1000;      % unit:millisecond
w(ns,ntrace,nfrq) = 0;
absw(ns,ntrace,nfrq) = 0;
f = [0:(ns-1)/2]'/(ns*dt*2);
t = [0:ns-1]'*dt;
M = length(t);
N = length(f);
w1(M,N) = 0;

gLength = round(winT/(dt*1e3));
if rem(gLength, 2) == 0
    gLength = gLength+1;
end

hLength = round(winF/(dt*1e3));
if rem(hLength, 2) == 0
    hLength = hLength+1;
end
g = window_m(gLength, 'gauss', k1);
h = window_m(hLength, 'gauss', k2);

sgydata = zeros(ns, 1, 'single');
segy_format = sgy400(13);
switch segy_format
    case 1
        sgytrace=zeros(ns, 1, 'uint32');
    case 5
        sgytrace=zeros(ns, 1, 'single');
    otherwise
        return;
end

for i = 1:nfrq
    for j = 1:N-1
        if (frq(i) >= f(j) && frq(i) < f(j+1))
            NN(i) = j;
            break;
        end
    end
end

for ktrace = 1:ntrace
    fseek(fidin , double(3200+400+(ktrace-1)*(ns*4+240)),'bof');
    sgyhead = fread(fidin, 120, 'int16');
    switch segy_format
        case 1
            sgytrace=fread(fidin, ns,'uint32');
            sgydata=single(ibm2ieee(sgytrace));
        case 5
             sgytrace=fread(fidin, ns,'single');
             sgydata=single(sgytrace);
        otherwise
     end

    [w1,t1,f1] = tfrspwv_m(hilbert(sgydata/10),dt,g,h);

    for i=1:nfrq
        w(:,ktrace,i)=w1(:,NN(i));
        absw(:,ktrace,i)=abs(w(:,ktrace,i));
        a(ktrace,i)=max(absw(floor(tt(ktrace)-10):floor(tt(ktrace)+10), ktrace,i));
    end
    
    per=ktrace/ntrace*100;
    if(rem(ktrace,2000)==0)     %the number can be modified according to total traces
       per1=num2str(per);
       per2=strcat(per1,'% is calculated!');
       fprintf('%s\n',per2);
    end
end
fclose(fidin);

fid = fopen(outfile,'w');
for i=1:ntrace
    for j=1:nfrq
        fprintf(fid,' %10.3f',a(i,j));
    end
    fprintf(fid,'\n');
end
fclose(fid);