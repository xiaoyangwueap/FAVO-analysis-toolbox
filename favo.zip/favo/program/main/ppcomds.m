%%%% main program ppcomds
%  This script scans the reflectivities and phases at a series of
%  porosities and water saturation with Chapman et al.(2002) model and 
%  wood's formula. The result(reflectivity and phase) is saved in two files
%  at the same directory.
%
%  Written by Mark Chapman, mchapman@staffmail.ed.ac.uk, 2004. 
%  Changed to matlab by Xiaoyang Wu, 5 July 2012, xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

deg = zeros(90,1);
amp = zeros(90,1);
phase = zeros(90,1);

xp = zeros(2,2);
yp = zeros(2,2);
epr = zeros(2,0);
epi = zeros(2,0);
esr = zeros(2,0);
esi = zeros(2,0);

t1 = zeros(2,2);
t2 = zeros(2,2);
wr = zeros(2,2);
wi = zeros(2,2);

m1r = zeros(2,2);
m1i = zeros(2,2);
m2r = zeros(2,2);
m2i = zeros(2,2);

refr = zeros(2,2);
refi = zeros(2,2);

xr = zeros(2,2);
yr = zeros(2,2);
xi = zeros(2,2);
yi = zeros(2,2);

xinvr = zeros(2,2);
xinvi = zeros(2,2);
yinvr = zeros(2,2);
yinvi = zeros(2,2);

xpin = zeros(2,2);
ypin = zeros(2,2);

npor = 30;       %number of porosity to be scanned
nsat = 21;       %number of saturation to be scanned
ssk = zeros(90,nsat,npor);      %3 dimension array for the storage of amplitude
ssl = zeros(90,nsat,npor);      %3 dimension array for the storage of phase

ssk1 = zeros(90,nsat*npor);     %2 dimension array for the storage of amplitude
ssl1 = zeros(90,nsat*npor);     %2 dimension array for the storage of phase
%%%% input upper medium properties
       ap = 3.200;
       bp = 1.570;
       rp = 2.50;

%%%% input lower medium properties
       freq = 20;
       file1 = strcat(pwd,'\favo\data\example8\amps_', num2str(freq), 'Hz.dat');
       file2 = strcat(pwd,'\favo\data\example8\phases_', num2str(freq),'Hz.dat');

[fidGrd1,msg1] = fopen(file1,'wt');
[fidGrd2,msg2] = fopen(file2,'wt');

for i = 1:npor,
   por = real(31-i)*0.01;
   for j = 1:nsat,
      sw = real(j-1)*0.05;

[cl, cm, r] = avo_rp(freq, sw, por);
lamr = real(cl);
lami = imag(cl);
mur =  real(cm);
mui = imag(cm);

%  input theta
    for index = 1:90,
       theta = (0.01745)*real(index);
       deg(index) = index;

%  calculate s1, common horizontal slowness

       s1=sin(theta)/ap;

%  calculate s3 for the four possibilities

       s3pp= sqrt( (1/(ap*ap)) - (s1*s1));
       s3sp= sqrt( (1/(bp*bp)) - (s1*s1));

%  calculate gamma

       gamp = 1-(2*bp*bp*s1*s1);


%  calculate impedance matrices for the upper medium

       xp(1,1) = ap*s1;
       xp(1,2) = bp*s3sp;
       xp(2,1) = -1*rp*ap*gamp;
       xp(2,2) = 2*rp*bp*bp*bp*s1*s3sp;

       yp(1,1) = -2*rp*ap*bp*bp*s1*s3pp;
       yp(1,2) = -1*rp*bp*gamp;
       yp(2,1) = ap*s3pp;
       yp(2,2) = -1*bp*s1;


% define coefficients of quadratic equation on slowness
% 
% arising from 5/11/04

       a1r = lamr*mur + 2*mur*mur + (-1)*lami*mui + (-2)*mui*mui;
   
       a1i = lami*mur + 2*mui*mur + lamr*mui + 2*mur*mui;

       a2r = s1*s1*(lamr +2*mur)*(lamr + 2*mur) + s1*s1*(-1)* ...
      (lami + 2*mui)*(lami + 2*mui) ...
       + s1*s1*mur*mur + (-1)*s1*s1*mui*mui + (-1)*r*mur + (-1)*r*lamr + ...
      (-1)*2*r*mur + (-1)*s1*s1*(lamr + mur)*(lamr + mur) ...
       + s1*s1*(lami + mui)*(lami + mui);

       a2i = 2*s1*s1*(lamr + 2*mur)*(lami + 2*mui) + 2*s1*s1*mur*mui ...
         + (-1)*r*mui + (-1)*r*lami + (-2)*r*mui ...
         + (-2)*s1*s1*(lamr + mur)*(lami + mui);

       a3r = s1*s1*s1*s1*( lamr*mur + 2*mur*mur + (-1)*lami*mui ...
        + (-2)*mui*mui) + (-1)*r*s1*s1*(lamr + 2*mur) + ...
      (-1)*r*s1*s1*mur + r*r;

       a3i = s1*s1*s1*s1*(lami*mur + 2*mui*mur + lamr*mui + 2*mur*mui) ...
        + (-1)*r*s1*s1*(lami + 2*mui) + (-1)*r*s1*s1*mui;


%  solve quadratic

       [t1r, t1i, t2r, t2i] = quad(a1r, a1i, a2r, a2i, a3r, a3i);


%  take square roots (biquadratic equation)

       [u1r, u1i] = square(t1r, t1i);

       [u2r, u2i] = square(t2r, t2i);


%  order the roots
     
        if ( abs(u1r) < abs(u2r) ),
          s3pr=u1r;
          s3pi=u1i;
          s3sr=u2r;
          s3si=u2i;
        else
          s3pr=u2r;
          s3pi=u2i;
          s3sr=u1r;
          s3si=u1i;
        end


% calculate the polarisations

       [epr, epi] = pol(lamr, lami, mur, mui, r, s1, s3pr, s3pi);

       [esr, esi] = pol(lamr, lami, mur, mui, r, s1, s3sr, s3si);

% normalize the eigenvalues

       norm = epr(1)*epr(1) + epr(2)*epr(2) + epi(1)*epi(1) + epi(2)*epi(2);

       norm = sqrt(norm);

       epr(1)=epr(1)/norm;
       epr(2)=epr(2)/norm;
       epi(1)=epi(1)/norm;
       epi(2)=epi(2)/norm;

       norm = esr(1)*esr(1) + esr(2)*esr(2) + esi(1)*esi(1) + esi(2)*esi(2);

       norm=sqrt(norm);

       esr(1)=esr(1)/norm;
       esr(2)=esr(2)/norm;
       esi(1)=esi(1)/norm;
       esi(2)=esi(2)/norm;

% check sign convention on polarisation vectors

       if ( epr(1) < 0),
         epr(1)=-1*epr(1);
         epr(2)=-1*epr(2);
         epi(1)=-1*epi(1);
         epi(2)=-1*epi(2);
       end

       if ( esr(1) < 0),
         esr(1)=-1*esr(1);
         esr(2)=-1*esr(2);
         esi(1)=-1*esi(1);
         esi(2)=-1*esi(2);
       end


% calculate impedence matrices for lower medium

       xr(1,1)= epr(1);
       xr(1,2)= esr(1);


       xi(1,1)= epi(1);
       xi(1,2)= esi(1);

       t1r= (lamr + 2*mur)*epr(2) - (lami + 2*mui)*epi(2);
       t1i= (lami + 2*mui)*epr(2) + (lamr + 2*mur)*epi(2);

       t2r= t1r*s3pr - t1i*s3pi;
       t2i= t1i*s3pr + t1r*s3pi;

       xr(2,1) = -1*( t2r + s1*lamr*epr(1) + (-1)*s1*lami*epi(1) );

       xi(2,1) = -1*( t2i + s1*lamr*epi(1) + s1*lami*epr(1) );


       t1r = (lamr + 2*mur)*s3sr - (lami + 2*mui)*s3si;
       t1i = (lamr + 2*mur)*s3si + (lami + 2*mui)*s3sr;

       t2r = t1r*esr(2) - t1i*esi(2);
       t2i = t1r*esi(2) + t1i*esr(2);

       xr(2,2) = -1*(s1*lamr*esr(1) + (-1)*s1*lami*esi(1) + t2r);

       yr(2,1) = epr(2);
       yi(2,1) = epi(2);
       yr(2,2) = esr(2);
       yi(2,2) = esi(2);

       t1r = s3pr*epr(1) - s3pi*epi(1);
       t1i = s3pi*epr(1) + s3pr*epi(1);

       t2r = s1*epr(2) + t1r;
       t2i = s1*epi(2) + t1i;

       yr(1,1) = -1*(mur*t2r - mui*t2i);
       yi(1,1) = -1*(mur*t2i + mui*t2r);

       t1r = s3sr*esr(1) - s3si*esi(1);
       t1i = s3sr*esi(1) + s3si*esr(1);

       t2r = s1*esr(2) + t1r;
       t2i = s1*esi(2) + t1i;

       yr(1,2) = -1*(mur*t2r - mui*t2i);
       yi(1,2) = -1*(mur*t2i + mui*t2r);

%  calculate inverses

       xpin = rinv(xp);
       ypin = rinv(yp);

%  calculate reflection matrix

       t1 = rmult(xpin, xr);
       t2 = rmult(ypin, yr);
       m1r = rsubt(t1, t2);
       t1 = rmult(xpin, xi);
       t2 = rmult(ypin, yi);
       m1i = rsubt(t1, t2);

       t1 = rmult(xpin, xr);
       t2 = rmult(ypin, yr);
       wr = radd(t1, t2);
       t1 = rmult(xpin, xi);
       t2 = rmult(ypin, yi);
       wi = radd(t1, t2);

       [m2r, m2i] = dcinv(wr, wi);

       [refr, refi] = dcmult(m1r, m1i, m2r, m2i);

       phase(index)= atan2( refi(1,1), refr(1,1) );

       amp(index) = sqrt( refr(1,1)*refr(1,1) + ...
           refi(1,1)*refi(1,1) );
       
       ssk(index,j,i) = amp(index); 
       ssk1(index,j+(i-1) * nsat) = amp(index);
       ssl(index,j,i)=phase(index)*180/3.1415926;
       ssl1(index,j+(i-1) * nsat) = phase(index)*180/3.1415926;
       
    end
   end
end

fid1 = fopen(file1,'w');
fid2 = fopen(file2,'w');
for i=1:npor*nsat
    for j=1:90
        fprintf(fid1,' %f     ', ssk1(j,i));
        fprintf(fid2,' %f     ', ssl1(j,i));
    end
    fprintf(fid1,'\n');
    fprintf(fid2,'\n');
end
fclose(fid1);
fclose(fid2);

for i = 1:npor*nsat,
%%%%draw reflectivity
          plot(deg(1:40), ssk1(1:40,i),'r','LineWidth',2);
          xlim([0 40]);
          ylim([0 0.5]);
          xlabel('incident angle/degree');
          ylabel('reflectivity');
%%%%draw phase
          %plot(deg(1:40), ssl1(1:40,i),'r');
          %xlim([0 40]);
          %ylim([0 180]);
          %xlabel('incident angle/degree');
          %ylabel('phase/degree');
          por(i) = 0.31-(floor((i-1)/nsat)*0.01+0.01);
          c=strcat('por=', num2str(por(i)));
          title(c);
          M(:,i) = getframe;
          if(mod(i,5)==0),pause;end   %ctrl+z can continue the animation.
          hold off;
end

movie(M,2,3);

