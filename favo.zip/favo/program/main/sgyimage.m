function [data, dmax, dmin] = sgyimage(infile, ntrace, t, cmax, cmin);
%  [data, dmax, dmin] = sgyimage(infile, ntrace, t, scale1, scale2) reads 
%  and displays the image of a iso-frequency section after spectral 
%  decomposition.It can also be used to display several iso-frequency 
%  sections in the same colorscale.
%
%  input:
%      infile:input iso-frequency section .sgy file which is derived from 
%             spectral decomposition
%      ntrace:number of traces in .sgy file
%      t: two element vector [tmin tmax] defining the interval of section to be
%         displayed
%      cmax: the max value of colorbar
%      cmin: the min value of colorbar
%
%  output:
%      data: the data stored in sgy file
%      dmax: the max value of the data to be displayed, provide reference for
%            cmax value.
%      dmin: the min value of the data to be displayed, provide reference for
%            cmin value.
%
%  Example:
%        infile1 = 'D:\MATLAB\R2008a\work\favo\data\example2\IL1605_10Hz.sgy';
%        infile2 = 'D:\MATLAB\R2008a\work\favo\data\example2\IL1605_20Hz.sgy';
%        ntrace = 141;
%        t = [0.5 2];
%        figure,subplot(1,2,1),
%        [data1,dmax1,dmin1] = sgyimage(infile1, ntrace, t);hold on;
%        subplot(1,2,2),
%        [data2,dmax2,dmin2] = sgyimage(infile2, ntrace, t);
%
%  14 July 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

if (nargin <= 1),
    error('At least 2 parameter is required!');
elseif (nargin == 2),
    t = [0 1]; cmax = 2000000; cmin = 0.0001;
elseif (nargin == 3),
    cmax = 1000000; cmin = 0.0001;
elseif (nargin == 4),
    cmin = 0.0001;
end

if (exist(infile) == 0),
    error('input files dont exist, please check!');
end

sgy3200 = zeros(1600,1, 'uint16');
sgy400 = zeros(200,1, 'uint16');
sgyhead = zeros(120,1, 'int16');

fidin = fopen(infile,'r','ieee-be');
sgy3200 = fread(fidin, 1600, 'uint16');
sgy400 = fread(fidin, 200, 'uint16');
ns = sgy400(11);
dt = sgy400(9)/1000000;
segy_format = sgy400(13);
sgydata = zeros(ns, 1, 'single');
data = zeros(ns, ntrace);


%define data which is to be displayed
t_start = floor(t(1)/dt);
t_end = floor(t(2)/dt);
nsd = zeros(t_end - t_start+1, 1, 'single');
ntr = zeros(t_end - t_start+1, 1, 'single');
nsd = (t_start:t_end)';
nnd = length(nsd);
ntr = (1:ntrace)';
dd = zeros(nnd, ntrace);

switch segy_format
    case 1
         sgytrace = zeros(ns, 1, 'uint32');
    case 5
         sgytrace = zeros(ns, 1, 'single');
    otherwise
    return;
end

for ktrace = 1:ntrace
fseek(fidin , double(3200+400+(ktrace-1)*(ns*4+240) ),'bof');
sgyhead = fread(fidin, 120, 'int16');
    switch segy_format
        case 1
           sgytrace = fread(fidin, ns,'uint32');
           sgydata = single(ibm2ieee(sgytrace));
        case 5
           sgytrace = fread(fidin, ns,'single');
           sgydata = single(sgytrace);
        otherwise 
    end
    data(:,ktrace) = sgydata;
end
fclose(fidin);

dd = data(t_start:t_end, :);
dmax = max(max(dd));dmin = min(min(dd));

pcolor(ntr, nsd, dd);
shading interp;
colormap(jet);
set(gca,'ydir', 'reverse')
title('Spectrum');
xlabel('Trace number');
ylabel('Time (second)')
colorbar;
caxis([cmin,cmax]);


