function [tfrx,t,f] = wv1d(x,dt)
%  [TFR,T,F] = wv1d(x, dt) applies the Wigner-Ville transform
%  to an 1D discrete-time signal x.
%
%  input:
%      x: the 1D signal
%      dt: time interval (unit: second)
%
%  output:
%      tfrx: the spectral amplitudes of x
%      t: time series
%      f: frequency series
%
%  Example:
%       infile = 'D:\MATLAB\R2008a\work\favo\data\example1\model.dat';
%       x = load(infile);
%       [tfr,t,f] = wv1d(x, 0.001);
%
%  15 Jun 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

if (nargin < 1),
    error('At least 1 parameter is required');
elseif (nargin == 1),
    dt=0.001;
end;

N = length(x);
t = (1:N);
[tfrx,t,f] = tfrwv_m(hilbert(x),dt);
M = length(f);

%normalize to [-1,1]
%max1=max(max(tfrx));
%min1=min(min(tfrx));
%for i=1:M
%    for j=1:N
%       tfrx(i,j)=(tfrx(i,j)-min1)/(max1-min1);
%   end
%end

figure;
subplot(1,2,1);plot(x,t); 
set(gca,'ydir', 'reverse');
title('Synthetic trace');
ylabel('Time (S)');
ylim([t(1) t(end)]);

subplot(1,2,2);
pcolor(f,t,tfrx);
shading interp;
colormap(jet);
set(gca,'ydir', 'reverse')
title('Spectrum');
xlabel('Frequency (Hz)');
ylabel('Time (second)')
xlim([0 100]);

tmin = min(t);tmax = max(t);fmin = min(f);fmax = max(f);
path = pwd;
GrdFile = strcat(path,'\favo\data\example1\wvd.grd');
tfrx = flipud(tfrx);   %flipud(A):turn up and down     fliplr(A):turn left and right     rot90(A):rotate 90 degree
WriteGrd(tfrx,GrdFile,fmin,fmax,tmin,tmax)





