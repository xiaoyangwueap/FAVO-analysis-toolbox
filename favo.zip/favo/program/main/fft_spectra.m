function [] = fft_spectra(infile, ntrace);
%  fft_spectra(infile,ntrace) compute the spectrum of four traces from a .sgy
%  file with Fast Fourier Transform to help analyze the dominant frequency 
%  and bandwidth.
%
%  input:
%      infile: .sgy file with its path;
%      ntrace:number of trace in the .sgy file;
%
%  Example:
%        infile = 'D:\MATLAB\R2008a\work\favo\data\example2\IL1605.sgy';
%        ntrace = 141;
%        fft_spectra(infile, ntrace);
%
%  16 Jun 2012, Xiaoyang Wu, xywu@bgs.ac.uk
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

if (nargin <=1),
    error('2 parameters are required.');
end
if (ntrace<=4),
    error('The traces in the file is not enough!');
end

[sgydata, dt, ns] = readmysegy(infile, ntrace);
n1 = round(ntrace/4);
n2 = round(ntrace/3);
n3 = round(ntrace/2);
n4 = round(ntrace/1.2);

a = sgydata(:,n1);
fa = abs(fft(a));
frq = [1:ns]/(ns*dt);
len = floor(ns/2);
figure,subplot(2,2,1),
plot(frq(1:len),fa(1:len));
xlabel('frequency/Hz');
ylabel('Amplitude');

a = sgydata(:,n2);
fa = abs(fft(a));
frq = [1:ns]/(ns*dt);
len = floor(ns/2);
subplot(2,2,2),
plot(frq(1:len),fa(1:len));
xlabel('frequency/Hz');
ylabel('Amplitude');

a = sgydata(:,n3);
fa = abs(fft(a));
frq = [1:ns]/(ns*dt);
len = floor(ns/2);
subplot(2,2,3),
plot(frq(1:len),fa(1:len));
xlabel('frequency/Hz');
ylabel('Amplitude');

a = sgydata(:,n4);
fa = abs(fft(a));
frq = [1:ns]/(ns*dt);
len = floor(ns/2);
subplot(2,2,4),
plot(frq(1:len),fa(1:len));
xlabel('frequency/Hz');
ylabel('Amplitude');

