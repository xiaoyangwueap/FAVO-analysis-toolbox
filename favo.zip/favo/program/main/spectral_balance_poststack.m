function [data_b] = spectral_balance_poststack(infile, ntrace, frq);
%  [data_b] = spectral_balance_poststack(infile, ntrace, frq) calculates the 
%  balanced spectral amplitude for post-stack data. the value of time horizon 
%  is stored in a .dat file.
%  
%  input:
%      infile: input .dat file storing the time horizon. this file
%              can include more than one column, but the last one column must 
%              be the time horizon(unit:second). the segy data to be balanced 
%              must also be prepared in the same directory, with the format 
%              '_10Hz.sgy' replacing '.dat'.
%      ntrace: number of trace in the .sgy file
%      frq: frequecy sections for spectral balance, first one must be the
%           reference frequency, others must be sorted in ascending order.
%  
% output:
%    data_b: three-dimension array storing the balanced spectral ampllutude
%    at each frequency for each trace at each time position.
%
%  Example:
%  infile = 'D:\MATLAB\R2008a\work\favo\data\example2\IL1605.dat';
%  frq = [30 10 20 40 50];
%  ntrace = 141;
%  spectral_balance_poststack(infile, ntrace, frq);
%  
%  19 Jun 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

if (nargin <=2 || nargin > 3),
    error('3 parameters are required.');
end;

nfrq = length(frq);           %Number of frequencies
infile_sgy = cell(nfrq,1);    %files that store the .sgy data to be balanced, must be in the same directory as infile
outfile_sgy = cell(nfrq,1);   %files that store the balanced .sgy data, must be in the same directory as infile
time1 = load(infile);
[m,n] = size(time1);
if (n == 1),                  %only one column in the infile
    time = time1;
elseif (n > 1),               %if there is more than one column in infile,using the last column
    time = time1(:,n);
end

if (m ~= ntrace),
    error('please check the infile or the number of traces!');
end

sgy3200 = zeros(1600,1, 'uint16');
sgy400 = zeros(200,1, 'uint16');
sgyhead = zeros(120,ntrace, 'int16');

for i = 1:nfrq
    a = strcat('_', num2str(frq(i)), 'Hz.sgy');
    b = strcat('_', num2str(frq(i)), 'Hzb.sgy');
    infile_sgy{i} = strrep(infile, '.dat', a);     %replace '.dat' in infile with string a;
    index = exist(infile_sgy{i},'file');
    if (index == 0),
        error('Segy file does not exist,please check!');
    end
    outfile_sgy{i} = strrep(infile, '.dat', b);    %files for output;
end

[da, dt, ns, sgy3200, sgy400, sgyhead] = readmysegy(infile_sgy{1}, ntrace);
data = zeros(ns, ntrace, nfrq, 'single');
data_b = zeros(ns, ntrace, nfrq, 'single');

for i = 1:nfrq
    data(:,:,i) = readmysegy(infile_sgy{i}, ntrace);
end

nt = floor(time/dt);
t_win = 10;               %time window for calculating the RMS amplitude

for i = 1:nfrq
    for j = 1:ntrace;
        m(j,i) = 0;
        s=data(:,j,i);
        for k = nt(i)-t_win:nt(i)+t_win;
            m(j,i) = m(j,i)+s(k)*s(k);       %max(B1(j,i));
        end
        m(j,i)=sqrt(m(j,i)/(2*t_win+1));
    end
end

for i = 1:nfrq
    for j = 1:ntrace;
        aIF(j,i)=m(j,1)/m(j,i);
    end
end

for i = 1:nfrq
    for j=1:ntrace;
         for k=1:ns;
             data_b(k,j,i)=data(k,j,i)*aIF(j,i);
         end
    end
end

for i = 1:nfrq
    writemysegy(outfile_sgy{i}, ntrace, sgy3200, sgy400, sgyhead, data_b(:,:,i));
end
