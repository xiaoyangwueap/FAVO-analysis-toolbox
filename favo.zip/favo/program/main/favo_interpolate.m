%%%This script is used to interpolate pre-stack data with different
%%%trace interval to the  equal interval. 
% 
%  20 Jun 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

clear all
close all

%%%% specify the range of inline, xline and offset %%%%
path = pwd;
in1_data_file = strcat(path,'\favo\data\example5\IL1605_prestack.sgy');
%in1_data_file = 'D:\MATLAB\R2008a\work\favo\data\example5\IL1605_prestack.sgy';
inline_begin = 1605;  inline_end=1605;  inline_step=1; inline_bin=1;
xline_begin  = 1700; xline_end =1840; xline_step=1; xline_bin=1;
offset0 = 0; offset1 = 2550;

% in1_data_file = 'Z:\IL1608.sgy';
% inline_begin = 1608;  inline_end=1608;  inline_step=1; inline_bin=1;
% xline_begin  = 1700; xline_end =1840; xline_step=1; xline_bin=1;
% offset0 = 0; offset1 = 2550;

% in1_data_file = 'Z:\reproduce\XL1012\XL1012.sgy';
% inline_begin =1442;  inline_end=1581;  inline_step=1; inline_bin=1;
% xline_begin  =1012; xline_end =1012; xline_step=1; xline_bin=1;
% offset0=0; offset1=2550;

out1_data_file = strrep(in1_data_file,'.sgy','_sort.sgy') ;  
minoffset = 100;
maxoffset = 1500;
doffset = 50;
pk = minoffset:doffset:maxoffset;
nn = length(pk);
%%%% specify the range of inline, xline and offset %%%%

% extract the index file from sgy file 
fdavo_extract_sgyhdr_hdi(in1_data_file);
hdi_filename = strcat(in1_data_file,'.hdi'); 
eval(['load ',hdi_filename,'  -mat']) ;
NSAMPLES = hdi_nsamples; 
nsamples = hdi_nsamples; 
DT = hdi_dt;

sgyin1_fid = fopen(in1_data_file,'r','ieee-be');
sgy3200 = zeros(3200,1,'uint8') ; 
sgy400 = zeros(400,1,'uint8') ;
sgy400w = zeros(400,1,'uint8') ;

sgyout1_fid = fopen(out1_data_file,'w','ieee-be');

% write segy file 3200 + 400 bytes head
sgy3200 = fread(sgyin1_fid, 3200, 'uint8'); 
sgy400 = fread(sgyin1_fid, 400, 'uint8'); 
sgy400w = sgy400;
sgy400w(26) = 5;
fwrite(sgyout1_fid, sgy3200,'uint8');
fwrite(sgyout1_fid, sgy400w,'uint8');

in1_sgytraces = zeros(NSAMPLES,60,'single') ; 
in1_sgyheads = zeros(60,60,'uint8');

out1_sgytraces = zeros(NSAMPLES,1,'single') ;
out1_sgyheads = zeros(60,1,'uint8');


tic
kinline = 0;
for inline_k = inline_begin:inline_step:inline_end
      kinline = kinline+1 ;
      kxline = 0;
      
      for xline_k = xline_begin:xline_step:xline_end
          kxline = kxline+1 ;
          xline_k
          inline_k
 
          ok_traces = find( (hdi_inline == inline_k)&(hdi_xline == xline_k )&(hdi_aoffset > offset0)&(hdi_aoffset < offset1) ) ;
          total_traces = length(ok_traces);
          
          if(total_traces < nn)
   
              ok_traces = find( (hdi_inline>=(inline_k-inline_bin))&(hdi_inline<=(inline_k+inline_bin))&...
                (hdi_xline >= (xline_k - xline_bin))&(hdi_aoffset > offset0)&(hdi_aoffset < offset1)&(hdi_xline <= (xline_k + xline_bin))) ; % 
              total_traces=length(ok_traces);
              
             if(total_traces < nn)
   
              ok_traces=find( (hdi_inline>=(inline_k-inline_bin))&(hdi_inline<=(inline_k+inline_bin))&...
                (hdi_xline>=(xline_k - xline_bin-1))&(hdi_aoffset>offset0)&(hdi_aoffset<offset1)&(hdi_xline<=(xline_k + xline_bin+1))) ; % 
              total_traces=length(ok_traces);
              end
              
          end
          
               double_location = double(hdi_location(ok_traces));   %The byte location of double precision seismic data
               aoffset = hdi_aoffset(ok_traces);
               [aoffset,aoffset_index] = sort(aoffset);
               double_location = double_location(aoffset_index);
               
               in1_sgyheads = zeros(60,total_traces,'uint32');
               in1_sgytraces = zeros(NSAMPLES,total_traces,'single');
               in2_sgytraces = zeros(NSAMPLES,total_traces,'uint32');
                              
               
               for ntrace = 1:1:total_traces
                    fseek(sgyin1_fid,double_location(ntrace) , 'bof');  
                    in1_sgyheads(:,ntrace) = fread(sgyin1_fid,60,'uint32');
                    in2_sgytraces(:,ntrace) = fread(sgyin1_fid, nsamples,'uint32');
                    in1_sgytraces(:,ntrace) = single(ibm2ieee(in2_sgytraces(:,ntrace)));
               end
               
               out1_sgyheads = zeros(60,1,'uint32'); 
               out1_sgytraces = zeros(NSAMPLES,1,'single'); 
               
               %minoffset=aoffset(1);maxoffset=aoffset(end);

               for ntrace = 1:1:length(minoffset:doffset:maxoffset)
                    tmpoffset = minoffset + doffset*(ntrace-1);
                    [tmp,tmpindex] = min(abs(aoffset-tmpoffset));
                    out1_sgyheads = in1_sgyheads(:,tmpindex);
                    %out1_sgytraces=in1_sgytraces(:,tmpindex);
                    out1_sgytraces = favo_insert(in1_sgytraces,aoffset,tmpoffset);
                    out1_sgyheads(6) = xline_k ;
                    out1_sgyheads(10) = tmpoffset;
                    out1_sgyheads(48) = inline_k;
                    out1_sgyheads(49) = xline_k; 
                    fwrite(sgyout1_fid, out1_sgyheads(:,1),'uint32');
                    fwrite(sgyout1_fid, out1_sgytraces(:,1),'single');
               end
      end
end
toc

fclose(sgyin1_fid);
fclose(sgyout1_fid);
