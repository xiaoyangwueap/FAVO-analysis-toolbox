function [] = spwv2d(infile,ntrace,frq,winT,winF);
%  [] = spwv2d(infile,ntrace,frq,winT,winF) computes spectrum of 2D .sgy 
%  format seismic signal using the smoothed pseudo Wigner-Ville transform.
%  
%  input:
%      infile: input .sgy file storing a 2D prestack or poststack seismic
%              signal
%      ntrace: number of traces in .sgy file
%      frq: frequencies for spectral decomposition
%      winT: time window length(ms), equal to wavelet length
%      WinF: frequency window(ms), equal to 2*winT
%  
%  Example1:post-stack
%        infile = 'D:\MATLAB\R2008a\work\favo\data\example2\IL1605.sgy';
%        spwv2d(infile,141,[10 20 30 40 50],30,60);
%  in the example, ntrace=141;
%  Example2:pre-stack
%        infile = 'D:\MATLAB\R2008a\work\favo\data\example4\1800.sgy';
%        spwv2d(infile,29,[10 20 30 40],30,60);
%  in the example, ntrace=29;
%
%  16 Jun 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

if (nargin <=1),
    error('At least 2 parameter is required.');
elseif (nargin == 2),
    frq = [10,20,30,40,50];  winT = 30; winF = 60;
elseif (nargin == 3)
    winT = 30; winF = 60;    %Time and frequency windows in ms
elseif (nargin == 4)
    winF = 60;
end;

sigma1 = 0.18;
sigma2 = 0.36;
k1 = exp(-1/(2*sigma1^2));
k2 = exp(-1/(2*sigma2^2));
nfrq=length(frq);         %Number of frequencies

sgy3200 = zeros(1600,1, 'uint16');
sgy400 = zeros(200,1, 'uint16');
sgy400n = zeros(200,1, 'uint16');
sgyhead = zeros(120,1, 'int16');

%data_filename=fullfile(data_dir, segyfile(1).name);

fidin = fopen(infile,'r','ieee-be');
sgy3200 = fread(fidin, 1600, 'uint16');
sgy400 = fread(fidin, 200, 'uint16');

ns = sgy400(11);
dt = sgy400(9)/1000000;

gLength = round(winT/(dt*1e3));
if rem(gLength, 2) == 0
    gLength = gLength+1;
end

hLength = round(winF/(dt*1e3));
if rem(hLength, 2) == 0
    hLength = hLength+1;
end
g = window_m(gLength, 'gauss', k1);
h = window_m(hLength, 'gauss', k2);

sgy400n = sgy400;
segy_format = sgy400(13);
sgy400n(13) = 5;

sgydata=zeros(ns, 1, 'single');
switch segy_format
        case 1
            sgytrace=zeros(ns, 1, 'uint32');
        case 5
            sgytrace=zeros(ns, 1, 'single');
        otherwise
        return;
end

w = zeros(ns,nfrq);
absw = zeros(ns,nfrq);
f = [0:(ns-1)/2]'/(ns*dt*2);
t = [0:ns-1]'*dt;
M = length(t);
N = length(f);
w1 = zeros(M,N);
outfile = cell(nfrq,1);

for i=1:nfrq
    a = strcat('_', num2str(frq(i)), 'Hz.sgy');
    outfile{i} = strrep(infile, '.sgy', a);     %replace '.sgy' in string infile with string a;
    fidout(i) = fopen(outfile{i}, 'w','ieee-be');
    fwrite(fidout(i), sgy3200, 'uint16');
    fwrite(fidout(i), sgy400n, 'uint16');       %write .sgy files in IEEE format
end

for i = 1:nfrq
    for j = 1:N-1
        if (frq(i) >= f(j) && frq(i) < f(j+1))
             NN(i) = j;
             break;
        end
    end
end

for ktrace = 1:ntrace
    fseek(fidin , double(3200+400+(ktrace-1)*(ns*4+240)),'bof');
    sgyhead = fread(fidin, 120, 'int16');
    switch segy_format
        case 1
           sgytrace=fread(fidin, ns,'uint32');
           sgydata=single(ibm2ieee(sgytrace));
        case 5
           sgytrace=fread(fidin, ns,'single');
           sgydata=single(sgytrace);
        otherwise 
    end

    [w1,t1,f1] = tfrspwv_m(hilbert(sgydata/10),dt,g,h);
    
    for i = 1:nfrq
        w(:,i) = w1(:,NN(i));
        absw(:,i) = abs(w(:,i));
        fwrite(fidout(i), sgyhead, 'int16') ;
        fwrite(fidout(i), single(absw(:,i)), 'single') ;
    end

    per=ktrace/ntrace*100;
    if(rem(j,100)==0)
        per1=num2str(per);
        per2=strcat(per1,'% is calculated!');
        fprintf('%s\n',per2);
   end
end

for i = 1:nfrq
    fclose(fidout(i));
end
fclose(fidin);



