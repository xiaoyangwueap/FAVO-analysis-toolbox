function [] = cwt2d(infile,ntrace,frq);
%  This function computes spectrum of 2D .sgy format seismic signal using 
%  the continuous wavelet transform.
%  
%  input:
%      infile: input .sgy file storing a 2D poststack seismic signal
%      ntrace: number of traces in .sgy file
%      frq: frequencies for spectral decomposition
%  
%  Example:
%        infile = 'D:\MATLAB\R2008a\work\favo\data\example2\IL1605.sgy';
%        cwt2d(infile,141,[10 20 30 40]);
%  in the example, ntrace = 141;
%
%  17 Jun 2012, Xiaoyang Wu, 
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

if (nargin <= 1),
    error('At least 2 parameter is required.');
elseif (nargin == 2),
    frq = [10,20,30,40,50];
end;

nfrq = length(frq);         %Number of frequency

sgy3200 = zeros(1600,1, 'uint16');
sgy400 = zeros(200,1, 'uint16');
sgyhead = zeros(120,1, 'int16');

fidin = fopen(infile,'r','ieee-be');
sgy3200 = fread(fidin, 1600, 'uint16');
sgy400 = fread(fidin, 200, 'uint16');

ns = sgy400(11);
dt = sgy400(9)/1000000;

sgy400n = sgy400;
segy_format = sgy400(13);
sgy400n(13) = 5;

sgydata = zeros(ns, 1, 'single');
switch segy_format
    case 1
        sgytrace = zeros(ns, 1, 'uint32');
    case 5
        sgytrace = zeros(ns, 1, 'single');
    otherwise
        return;
end

w = zeros(ns);
absw = zeros(ns);
wavelet = 'mmor';
outfile = cell(nfrq,1);

for i = 1:nfrq
    a = strcat('_', num2str(frq(i)), 'Hz.sgy');
    outfile{i} = strrep(infile, '.sgy', a);   %replace '.sgy' in string infile with string a;
    fidout(i) = fopen(outfile{i}, 'w','ieee-be');
    fwrite(fidout(i), sgy3200, 'uint16');
    fwrite(fidout(i), sgy400n, 'uint16');
end

for ktrace = 1:ntrace
fseek(fidin , double(3200+400+(ktrace-1)*(ns*4+240) ), 'bof' );
sgyhead = fread(fidin, 120, 'int16');
    switch segy_format
        case 1
           sgytrace = fread(fidin, ns,'uint32');
           sgydata = single(ibm2ieee(sgytrace) );
        case 5
           sgytrace = fread(fidin, ns,'single');
           sgydata = single(sgytrace);
        otherwise 
    end 

    for i = 1:nfrq
        scale = centfrq(wavelet)/(dt*frq(i));
        w = cwt(sgydata,scale,wavelet);
        absw = abs(w);
        fwrite(fidout(i), sgyhead, 'int16') ;
        fwrite(fidout(i), single(absw), 'single') ;
    end
end

for i = 1:nfrq
    fclose(fidout(i));
end
fclose(fidin);