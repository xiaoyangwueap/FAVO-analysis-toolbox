function [vp,qip] = dispersion_main(por,sw)
%  This function calculates the variation of 1/Q with water saturation by 
%  calling the subroutine avo_rp.m, which is used to calculate the elastic 
%  constant at a certain frequency using Chapman et al.(2002) model
%  with wood's formula, which is used to calculate the elastic moduli of 
%  mixture.
%
%  input:
%       por: porosity
%       f0: frequency
%
%  output:
%       qi:invere quality factor 1/Q
%
%  Example:
%        f0 = 50;
%        por = 0.10;
%        qip = attenuation_main(por,f0);
%
%  3 July 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

for i = 1:1000
    f(i) = i;
    [lfw(i), mfw(i), r(i)] = avo_rpclass2(f(i), sw, por);
    qip(i) = imag(lfw(i) + 2 * mfw(i))/real(lfw(i) + 2 * mfw(i));
    qis(i) = imag(mfw(i))/real(mfw(i));
    vp(i) = sqrt(real(lfw(i) + 2 * mfw(i))/r(i));
    vs(i) = sqrt(real(mfw(i)/r(i)));
end

figure,subplot(1,2,1),plot(log10(f),vp,'LineWidth',2);
xlabel('Frequency(Hz)');
ylabel('P-wave velocity(m/s)');
% subplot(1,3,2),plot(sg,vs,'LineWidth',2);
% xlabel('Sg(fractal)');
% ylabel('S velocity');
subplot(1,2,2),plot(log10(f),qip,'LineWidth',2);
xlabel('Frequency(Hz)');
ylabel('Attenuation(1/Q)');

file = strcat(pwd,'\Qi',num2str(por),'.dat');
[fidGrd, msg] = fopen(file,'wt');
for k = 1:1000
    fprintf(fidGrd,'%e %e %e\n',f(k),vp(k),qip(k));
end
fclose(fidGrd);
