function [] = draw_suwaveform(infile, start_time, end_time)
%  This function draws the waveform of a .su file generated from Seismic
%  Unix; the .su file contains one CDP gather data.
%
%  infile = 'Z:\aniseis\fdep30g_z.su';
%  infile = 'Z:\aniseis\fdep30g_z_n.su';
%
%  Example:
%        infile = 'Z:\aniseis\fdep30g_z.su';
%        start_time = 0.55; 
%        end_time = 1.1;
%        draw_suwaveform(infile, start_time, end_time);
%
%  20 Jun,2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

[Data,SuTraceHeaders,SuHeader,HeaderInfo] = ReadSu(infile,'endian','b');
dt = SuHeader.dt/1000000;
ns = SuHeader.ns;
offset = HeaderInfo.offset;
ds =offset(3)-offset(2);
ntrace = length(offset);
start_sample = start_time/dt;
end_sample = end_time/dt;

Dshow=Data(start_sample:end_sample, 2:ntrace);
x=offset(2:ntrace);    %length of x must be the same as Dshow
y=[start_time:dt:end_time];         %length of y must be the same as Dshow
figure, %subplot(3,1,1),hold on;
wigb_m(Dshow,0.10,x,y,1000,[0 0 0],1);
xlabel('offset(m)');
%title('(a)Class III AVO');
ylabel('Time (second)');
xlim([offset(2)-ds offset(ntrace)+ds]);
ylim([start_time end_time]);
set(gca,'YTick',[start_time:50*dt:end_time]);
