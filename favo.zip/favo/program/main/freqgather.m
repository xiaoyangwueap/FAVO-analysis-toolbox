function [a] = freqgather(infile1, infile2, ntrace, t0, frq, winT, winF)
%  this function is used to calculate spectral amplitude at a series of 
%  frequency (frequency gather) along a layer for post-stack seismic
%  data.
%
%  input:
%  infile1: input .sgy file storing poststack seismic data
%  infile2: input .dat file storing the time depth of horizontal layer for 
%           spectral calculation
%  ntrace: total traces of the .sgy file
%  t0: sometimes the .sgy profile does not started from 0s,t0 is the start
%      time of seismic section, unit:second
%  frq: frequencies for spectral decomposition
%  winT: time window length(ms), equal to wavelet length
%  WinF: frequency window(ms), equal to 2*winT
%
%  output:
%  a: two-dimension array storing spectral amplitudes of each trace
%  
%  Example:
%  infile1='D:\MATLAB\R2008a\work\favo\data\Example7\aline_500.sgy';
%  infile2='D:\MATLAB\R2008a\work\favo\data\Example7\t51_aline.dat';
%  [a] =freqgather(infile1, infile2, 471, 2.0, 1:1:60);
%
%  6 July 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

if (nargin <= 2),
    error('At least 3 parameter is required');
elseif (nargin == 3),
    t0 = 0; frq = 1:1:60;  winT = 30; winF = 60; 
elseif (nargin == 4),
    frq = 2:2:60;  winT = 30; winF = 60; 
elseif (nargin == 5),
      winT = 30; winF = 60;
elseif (nargin == 6),
     winF = 60;
end;

if (exist(infile1) == 0 || exist(infile2) == 0),
    error('input files dont exist, please check!');
end

sgy3200 = zeros(1600,1, 'uint16');
sgy400 = zeros(200,1, 'uint16');
sgyhead = zeros(120,1, 'int16');
fidin = fopen(infile1,'r','ieee-be');
sgy3200 = fread(fidin, 1600, 'uint16');
sgy400 = fread(fidin, 200, 'uint16');
ns = sgy400(11);
dt = sgy400(9)/1000000;
segy_format = sgy400(13);
sgydata = zeros(ns, 1, 'single');

switch segy_format
    case 1
         sgytrace = zeros(ns, 1, 'uint32');
    case 5
         sgytrace = zeros(ns, 1, 'single');
    otherwise
    return;
end

tt = load(infile2);
tt = floor((tt-t0)./dt);
[mm,nn] = size(tt);
if (mm == 1),
    tt = tt';
end

nfrq = length(frq);
a=zeros(ntrace,nfrq);      %storing the result

sigma1 = 0.18;
sigma2 = 0.36;
k1 = exp(-1/(2*sigma1^2));
k2 = exp(-1/(2*sigma2^2));
winT = 30;                 %Time window in ms
winF = 60;
gLength = round(winT/(dt*1e3));
if rem(gLength, 2) == 0
    gLength = gLength+1;
end
hLength = round(winF/(dt*1e3));
if rem(hLength, 2) == 0
    hLength = hLength+1;
end

g = window_m(gLength, 'gauss', k1);
h = window_m(hLength, 'gauss', k2);

w = zeros(ns,ntrace);
absw = zeros(ns,ntrace);
f = [0:(ns-1)/2]'/(ns*dt*2);
t = [0:ns-1]'*dt;
M = length(t);
N = length(f);
w = zeros(M,N);

for i = 1:1:nfrq
    for k = 1:N-1
        if (frq(i) >= f(k) && frq(i) < f(k+1))
            NN(i) = k;
            break;
        end
    end
end

for ktrace = 1:ntrace
fseek(fidin , double(3200+400+(ktrace-1)*(ns*4+240) ),'bof');
sgyhead = fread(fidin, 120, 'int16');
    switch segy_format
        case 1
           sgytrace = fread(fidin, ns,'uint32');
           sgydata = single(ibm2ieee(sgytrace));
        case 5
           sgytrace = fread(fidin, ns,'single');
           sgydata = single(sgytrace);
        otherwise 
    end
    
    [w1,t1,f1] = tfrspwv_m(hilbert(sgydata),dt,g,h);   %Gaussian window
    
    for i = 1:nfrq
        w(:,i) = w1(:,NN(i));
        absw(:,i) = abs(w(:,i));
        a(ktrace,i) = max(absw(tt(ktrace)-10:tt(ktrace)+10,i));
    end
    
    if(rem(ktrace, 500) == 0), fprintf('computing now ,dont shut down!!!\n');end
end
fclose(fidin);
a = a';

tmin = 1; tmax = ntrace;
fmin = min(frq);fmax = max(frq);
GrdFile = strrep(infile1, '.sgy', '_fg.grd');  %replace '.sgy' in string infile with string a;
WriteGrd(a, GrdFile, tmin, tmax, fmin, fmax);
