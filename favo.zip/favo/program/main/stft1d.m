function [tfr,t,f] = stft1d(x, htype, hlength, dt);
%  [TFR,T,F]=stft1d(x, htype, hlength, dt) computes the spectrum of a 1D 
%  signal x using the short-timeFourier transform.
%
%  input:
%      x: the 1D signal
%      htype: window type used in STFT
%             htype=0, Hamming window
%             htype=1, Hanning window
%             htype=2, Gaussian window
%             htype=3, Nuttall window
%      hlength: window length(unit:sample point)
%      dt: time interval (unit: second)
%
%  output:
%      tfr: the spectral amplitudes of x
%      t: time series
%      f: frequency series
%  
%  Example:
%         infile = 'D:\MATLAB\R2008a\work\favo\data\example1\model.dat'; 
%         x = load(infile);
%         [tfr,t,f] = stft1d(x, 0, 60, 0.001);
%
%  16 Jun 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

if (nargin < 1),
 error('At least 1 parameter is required');
elseif (nargin == 1),
 htype=0; hlength=floor(N/4); dt=0.001;
elseif (nargin == 2),
 hlength=floor(N/4);dt=0.001;
 elseif (nargin == 3),
dt=0.001;
end;

[m1,n1]=size(x);
if(m1 ~= 1 && n1 ~= 1),
    error('x should be one row or one column,please check!');
end
if (m1 == 1), x=x'; end

N=length(x);
[tfr,t,f] = tfrstft_m(hilbert(x),htype,hlength,dt); 
M=length(f);

max1=max(max(tfr));min1=min(min(tfr));

% normalize to [-1,1]
% for i=1:N
%     for j=1:M
%         tfr1(i,j)=(tfr1(i,j)-min1)/(max1-min1);
%         tfr2(i,j)=(tfr2(i,j)-min2)/(max2-min2);
%     end
% end

tfr=abs(tfr).^2;   %spectrogram
axisx=max(f);axisy=max(t);
figure;
subplot(1,2,1);plot(x,t); 
set(gca,'ydir', 'reverse');
title('Synthetic trace');
ylabel('Time (S)');
ylim([t(1) t(end)]);

subplot(1,2,2);
pcolor(f,t,tfr);
shading interp;
colormap(jet);
set(gca,'ydir', 'reverse');
title('Spectrum');
%COLORBAR('vert');
%set(gca,'CLim',[0,10e-18]);
xlabel('Frequency (Hz)');
ylabel('Time (second)');
xlim([0 100]);

tmin=min(t);tmax=max(t);fmin=min(f);fmax=max(f);
path=pwd;
GrdFile=strcat(path,'\favo\data\example1\stft.grd');
tfr=flipud(tfr);     %flipud(A):turn up and down     fliplr(A):turn left and right     rot90(A):rotate 90 degree
WriteGrd(tfr,GrdFile,fmin,fmax,tmin,tmax);


