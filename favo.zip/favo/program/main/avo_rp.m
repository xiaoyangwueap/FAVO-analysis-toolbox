function [lfw, mfw, r] = avo_rp(w, sw, por)
%  This function is used to calculate the frequency dependent lame constant
%  and density for multi-fluid mixture when changing porosity and water 
%  saturation by combining Chapman et al.(2002) model with Wood's formula.
%
%  input:
%       w: wave frequency
%       sw: water saturation
%       por:porosity
%
%  output:
%      lfw: lamda of fluids saturated rock at frequency w
%      mfw: mu of fluids saturated rock at frequency w
%      r: densit of rock with multi-fluids
%
%  written by Mark Chapman, 2004.
%  changed to Matlab by Xiaoyang Wu, 29 June 2012.
%  Edinburgh Anisotropy Project
%  British Geological Survey

zero1 = 0;
kw = 2.0;
kg = 0.2;
yw = 1;
yg = 0.02;

% define the reference parameters
vp0 = 3.020;
vs0 = 1.450;

% mixture saturated density 
r0 = 2.25;
f0 = 1;
sw0 = .59;

% fluid bulk modulus for mixture (GPa)
kf0 = 1/(sw0/kw+(1-sw0)/kg);
por0 = .16;
cd0 = .12;
tau0 = 1e-2*(sw0*yw+(1-sw0)*yg);
af0 = 1;
rf = sw0*1+(1-sw0)*0.07;
rm = (r0-por0*rf)/(1-por0);
       
% calculate the common elastic moduli
mu = vs0*vs0*r0;
lam = vp0*vp0*r0 - 2*mu;
[c11, c33, c12, c13, c44] = fdc(lam, mu, r0, zero1, af0, cd0,por0, kf0, tau0, f0);

lc = 2*lam - real(c12);
mc = 2*mu - real(c44);

% define the varying parameters
freq = w;

% varying fluid bulk modulus for fluid substitution (GPa)
kf  = 1/(sw/kw+(1-sw)/kg);
cd  = cd0;
af  = af0;
tau = 1e-2*(sw*yw+(1-sw)*yg);
r =  por*(sw*1+(1-sw)*0.07)+(1-por)* rm;

% calculate the final elastic modulus
[c11, c33, c12, c13, c44] = fdc(lam, mu, r0, zero1, af, cd, por, kf, tau, w);
cla = lc - lam;
cmu = mc - mu;
lfw = c12 + cla;
mfw = c44 + cmu;


function [c11, c33, c12, c13, c44] = fdc(lam, mu, rho, fd, af, cd, ppor, kf, tau, w)

%  This subroutine takes real values for the lamee constants (lam & mu), the density (rho) fracture 
%  density (fd), fracture length in meters (af), the microcrack density (cd), the porosity (ppor)
%  the parameter gamma (gam) related to fluid compressibility, the time constant (tau) related to the
%  inverse of the squirt flow frequency and the wave frequency (w).

%  The output is a complex elastic tensor, with the x_3 axis assumed to be the axis of symmetry. This 
%  elastic tensor is characterised by the constants c11, c33, c12, c13 and c44.

% parameter values
ar = 1E-3;
gamp = 1;
tauf = 5000*af*tau;
cpor = 4.187*cd*ar;
fpor = 4.187*fd*ar;

% some definitions                                              
po = (((lam+2*mu)/rho) - 2*(mu/rho))/(2*((lam+2*mu)/rho) - (mu/rho));
gam = (1.18*( 1 + (1.3333333)*((mu)/(kf))))/(1-po);
pi = 3.1415926535;
l2 = (lam*lam) + (1.33333333*lam*mu) +(0.8*mu*mu);
l3 = 4*(lam*lam + (1.33333*lam*mu) + (0.5333333*mu*mu) );
v = lam/(2*(lam+mu));
kap = lam+ (0.66666666*mu);
crit = (pi*mu*ar)/(2-2*v);
io = (cpor/ar)/( (cpor/ar) + ppor);
kc = (pi*mu*ar)/(2*(1-v)*kf);
beta = (fpor/ar)/((cpor/ar) + ppor);


% calculate d1 and d2, f1 and f2
z1=(io/(3 + 3*kc)) + (gamp - gamp*io);
z2=((i*w*tau)*( 1/(3 + 3*kc) -gamp))/(1+i*w*tau);
z3=io +( (io*beta)/(1+i*w*tauf));
a=z1 - (z2*z3);
b=beta/( (1+kc)*(1+i*w*tauf) );
z4=((1-io)*gam) + (( (1-io)*beta)/(1+i*w*tauf));
z5=(io + ((io*beta)/(1 + i*w*tauf)))* ((1+i*w*gam*tau)/(1+i*w*tau));
c= z4 + z5;
d1=a/c;
d2=b/c;
x1=io*d1*(1+i*w*gam*tau)/(1+i*w*tau);
x2= d1*(1-io);
x3=(((1/(3 + 3*kc)) -gamp)*io*i*w*tau)/(1+i*w*tau);
f1=(x1 + x2 + x3)/(1 + i*w*tauf);
v1=(i*w*tauf)/(1 + kc);
v2=(io*d2*(1+i*w*gam*tau))/(1+i*w*tau);
v3=d2*(1-io);
f2=(v1+v2+v3)/(1+i*w*tauf);


% end definiton of d1, d2, f1, f2
% define g1, g2, g3
g1=(i*w*tau)/( (1+i*w*tau)*(1+kc));
g2=(d1 +(d1*i*w*tau*gam) - (gamp*i*w*tau))/(1+i*w*tau);
g3=(d2*(1+i*w*gam*tau))/(1+i*w*tau);


% end of definition of g1, g2, g3
% calculation of c_11
aa1=(l2/crit) + ((32*(1-v)*mu)/(15*(2-v)*pi*ar));
aa2=(((l2/crit)+kap)*g1)+((((3*kap*kap)/crit) +3*kap)*g2)+( (((lam*kap)/crit)+lam)*g3);


% crack correction cpor*(aa1-aa2)
aa3=( (3*lam*lam + 4*lam*mu+ (mu*mu*(36+20*v)/(7-5*v)) )*3*(1-v))/(4*(1+v)*mu);
aa4=(1+(3*kap)/(4*mu))*(3*kap*d1 + lam*d2);


% porosity correction ppor*(aa3-aa4)
aa5=lam*lam/crit;
aa6=((3*lam*kap/crit)+(3*kap))*f1 +( ( (lam*lam/crit) + lam)*f2);


% fracture correction fpor*(aa5-aa6)
c11= (lam+2*mu) + ((-1)*cpor*(aa1-aa2)) + ((-1)*ppor*(aa3-aa4)) + ((-1)*fpor*(aa5-aa6));


% calculation of c33
bb2=(((l2/crit)+kap)*g1)+(( ((3*kap*kap)/crit) +3*kap)*g2)+(((((lam+2*mu)*kap)/crit)+(lam+2*mu))*g3);


% crack correction cpor*(aa1-bb2)
bb3=(1+((3*kap)/(4*mu)))*( (3*kap*d1) + ((lam+2*mu)*d2) );

       
% porosity correction ppor*(aa3-bb3)
bb4=(lam +2*mu)*(lam+2*mu)/crit;
bb5=(( (3*kap*(lam+2*mu)/crit) +3*kap)*f1) + f2*(((lam+2*mu)*(lam+2*mu)/crit) + lam + 2*mu);

       

% fracture correction fpor*(bb4-bb5)
c33=(lam+2*mu) + ((-1)*cpor*(aa1-bb2)) + ((-1)*ppor*(aa3-bb3)) + ((-1)*fpor*(bb4-bb5));


% calculation of c44
jj1=(0.2666666666667)*mu*mu*(1-g1)/crit;
jj2=((1.6)*(1-v)*mu)/(pi*ar*(2-v));

% crack correction cpor*(jj1 + jj2)
jj3=(15*(1-v)*mu)/(7-5*v);

% porosity correction ppor*jj3
vel=ppor*jj3;
jj4=(4*(1-v)*mu)/(pi*(2-v)*ar);

% fracture correction fpor*jj4
vel=fpor*jj4;
c44= mu + ((-1)*cpor*(jj1+jj2)) + ((-1)*ppor*jj3) + ((-1)*fpor*jj4);


% calculation of c12
kk1=(l3/crit) + ((32*(1-v)*mu)/(15*(2-v)*pi*ar));
kk2=(((l3/crit) + 4*kap)*g1) + (((12*kap*kap/crit) + 12*kap)*g2) + (((4*lam*kap/crit) + 4*lam)*g3);

% crack correction cpor*(kk1-kk2)
kk3= ((12*lam*lam + 16*lam*mu +(mu*mu*64/(7-5*v)))*3*(1-v))/(4*(1+v)*mu);
kk4=( (1.5*kap/mu) + 2)*(6*kap*d1 + 2*lam*d2);


% porosity correction ppor*(kk3-kk4)
kk5=4*lam*lam/crit;
kk6=(f1*( (12*kap*lam/crit) + 12*kap)) + (f2*( (4*lam*lam/crit) + 4*lam));

% fracture correction fpor*(kk5-kk6)
c12=0.5*( (4*lam+4*mu) + ((-2)*c11) + ((-1)*cpor*(kk1-kk2)) + ((-1)*ppor *(kk3-kk4)) + ((-1)*fpor*(kk5-kk6)) );


% calculation of c13
mm2=(((l3/crit) + 4*kap)*g1) + (((12*kap*kap/crit) + 12*kap)*g2)+(((4*(lam+mu) *kap/crit) + 4*(lam+mu))*g3);
 
% crack correction cpor*(kk1-mm2)
mm4=( (1.5*kap/mu) + 2)*(6*kap*d1 + (2*lam+2*mu)*d2);

% porosity correction ppor*(kk3-mm4)
mm5=(4*(lam+mu)*(lam+mu))/crit;
mm6=(f1*( (12*kap*(lam+mu)/crit) + 12*kap)) + (f2*( (4*(lam+mu)*(lam+mu)/crit)+ 4*(lam+mu)));

% fracture correction fpor*(mm5-mm6)
c13=0.5*( (4*lam+4*mu) + ((-1)*(c11 + c33)) + ((-1)*cpor*(kk1-mm2)) + ((-1)*ppor*(kk3-mm4)) + ((-1)*fpor*(mm5-mm6)) );



	

