function [t, amp] = ricker(freq, t0, d, dt, nsamp)
%  This function generates ricker wavelet. It can also be used to generate
%  other wavelet which is defined in ANISEIS.
%
%  input:
%      freq:frequency of wavelet
%      t0:the temporal position of max amplitude
%      d:max amplitude value
%      dt:sampling interval;
%      nsamp:number of samples
%      t:time position
%      amp:amplitude
%
%  output:
%  t:sampling time series
%  amp: amplitude of ricker wavelet
%
%  Example:
%          freq =25;
%          t0 = 0.2;
%          d = 1;
%          dt=0.001;
%          nsamp=500;
%          [t,amp] = ricker(freq, t0, d, dt, nsamp);
%
%  written by Mark Chapman, mchapman@staffmail.ed.ac.uk. 
%  changed to matlab by Xiaoyang Wu, 15 July 2012, xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

%dt = 1/nsamp;
t = zeros(nsamp,1);
amp = zeros(nsamp,1);

for i = 1:nsamp
    t(i) = (i-1)*dt;
	amp(i) = 0;
    amp(i) = pulse(7,freq,t0,t(i),d);
end

plot(t,amp,'r','LineWidth',2);
xlabel('time/s');
ylabel('amplitude');
c1 = num2str(freq);
c2 = num2str(dt);
c3 = num2str(nsamp);
str = strcat('f = ',c1,' Hz;','dt = ',c2,'s;','nsamp = ',c3);
title(str);

%---------------------------------------------------------------------
function amp1 = pulse(ntype,f,t0,t,d)
%%% aniseis-type pulse (1-6),7=ricker wavelet,8=gaussian
pi=3.1415926;
tp = t - t0;
w = 2.0*pi*f;
switch ntype
       case 1
            if(t < t0), amp1 = 0.0;end
            if(t >= t0) amp1 = exp(-(w*tp/d)^2)*sin(w*tp);end
       case 2
            if(t < t0), amp1 = 0.0;end
            if(t >= t0), amp1 = tp^2*exp(-(w*tp/d)^2)*sin(w*tp);end
       case 3
            amp1 = exp(-(w*tp/d)^2)*sin(w*tp);
       case 4
            amp1 = exp(-(w*tp/d)^2)*cos(w*tp);
       case 5
            amp1 = tp^2*exp(-(w*tp/d)^2)*sin(w*tp);
       case 6
            amp1 = tp^2*exp(-(w*tp/d)^2)*cos(w*tp);
       case 7
            amp1 = (1.0-2.0*(pi*f*tp)^2)*exp(-(pi*f*tp)^2);
       case 8
            amp1 = tp*exp(-w*w*tp*tp);
       otherwise
            amp1 = sin(w*tp);                
end
