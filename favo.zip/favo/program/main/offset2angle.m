function theta = offset2angle(infile, offset, td, dt)
%  theta = offset2angle(infile, offset, td, dt) transforms offset to
%  incident angle through velocities which is stored in infile.
%
%  input:
%      infile: the file storing velocity vp, which should be one column with the 
%              velocity for each sample
%      offset: offset for each trace
%      td: time depth of reflector
%      dt: time interval
%
%  output:
%      theta: incident angle transfered from offset
%
%  Example:
%         infile = 'D:\MATLAB\R2008a\work\favo\data\\example5\IL1605_vel.dat';
%         offset = 100:50:1500;
%         td = 1.40;
%         dt = 0.004;
%         theta = offset2angle(infile, offset, td, dt);
%
%  3 July 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

vp = load(infile);
ns = length(vp);
ntd = floor(td/dt);
ntrace = length(offset);

twt = zeros(ns,1);
h = zeros(ns,1);
theta = zeros(ntrace,1);

for i = 1:ns
     twt(i) = dt*(i-1);
end

% generate depth h from time samples, and offset x for each trace
for i = 1:ntd-1
     h(i+1) = h(i)+(twt(i+1)-twt(i))*vp(i+1)/2;
end

% given t --> vp & vs & theta
for i = 1:ntrace
    theta1(i) = atan(offset(i)/h(ntd));
    theta(i) = theta1(i)*180/3.14159;
end
