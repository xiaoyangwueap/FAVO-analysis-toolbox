function [] = favo_spwv(infile, infile_vp, ntrace, ncmp, start_cmp, frq)
%  This function computes the frequency dependent AVO attribute using spwv 
%  spectral decomposition method.
%
%  input:
%      infile: input .sgy file storing a 2D prestack seismic signal,spectral 
%              file should be end with '_10Hz.sgy',see example, another problem
%              is the path should be with no space.
%      infile_vp: input .dat file storing the velocity model, one column. (unit:m/s)
%      ntrace: number of traces in each cmp;
%      ncmp: number of cmp in .sgy file;
%      start_cmp: the No. of first cmp;
%      frq: spectrally decomposed frequencies, the first one should be
%           reference frequency, other frequencies should be listed in ascending order; 
%  
%  Example:
%  infile='D:\MATLAB\R2008a\work\favo\data\example5\IL1605_prestack_sort.sgy';
%  infile_vp='D:\MATLAB\R2008a\work\favo\data\example5\IL1605_vel.dat';
%  favo_spwv(infile,infile_vp,29,141,1700,[30 10 20 40 50]);
%
%
%%%%%%%%%%%%NOTICE: in the file vp.dat,the velocity should be only one column.
%%%%%%%%%%%%NOTICE: in the example, total_ntrace=4089,no space in the path,small window would be better.
%%%%%%%%%%%%NOTICE: the program favo_readsgy.m should be modified when changing inline to xline or xline to inline.
%
%  20 Jun 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

nfrq = length(frq);
infile_f = cell(nfrq,1);
for i = 1:nfrq
    a = strcat('_', num2str(frq(i)), 'Hz.sgy');
    infile_f{i} = strrep(infile, '.sgy', a);   %replace '.sgy' in string infile with string a;
end

%%%%%%%%%%%%%%%%%parameters may need to be specified%%%%%%%%%%%%%%
ns = 750;                   %ns=750;
min_offset = 50;
trace_space = 50;           %trace space
dt = 0.004;
%ncmp = 141;
%ntrace = 29;
start_point = 200; %the point starting for favo calculation
%total_ntrace=ntrace*ncmp;
mtpseis = 1;      %make sure there is no zero value in the trace because of balance.
%mute_trace = 10;
%spectral balance window
win1 = 0.85;  %start time of the window
win2 = 0.95;  %end time of the window
win_start = round(win1/dt);
win_end = round(win2/dt);
%%%%%%%%%%%%%%%parameters may need to be specified%%%%%%%%%%%%%%

% P- and S- wave Velocity
vp = zeros(ns,1);
vs = zeros(ns,1);
%%%%%%%%%%%%%%%%%parameters may need to be specified%%%%%%%%%%%%%%
vp = load(infile_vp);
%vs=(vp-1360)/1.16;
vs = 0.65 * vp - 502;
%%%%%%%%%%%%%%%parameters may need to be specified%%%%%%%%%%%%%%

% Two-way time
twt = zeros(ns,1);
h = zeros(ns,1);
i = 1;
for i = 1:ns
     twt(i) = dt*(i-1);
end

% Angle of incidence
theta = zeros(ns,ntrace);
pvel = zeros(ns,ntrace);
svel = zeros(ns,ntrace);

% generate depth h from time samples, and offset x for each trace
for i = 1:ns-1
     h(i+1) = h(i) + (twt(i+1)-twt(i))*vp(i+1)/2;
end
for j=1:ntrace
     x(j)=(min_offset+(j-1)*trace_space)/2;
end

% given t --> vp & vs & theta
for i=start_point:ns
     for j=1:ntrace
          pvel(i,j)=vp(i);
          svel(i,j)=vs(i);
          theta(i,j)=atan(x(j)/h(i));
          theta1(i,j)=theta(i,j)*180/3.14159;
     end
end

% Spec Decom Balancing using a Seismic Time Window Mean Value Averaging
% ~0.8s/0.004s=200th sample & ~1.0s/0.004s=250th sample
% ~1.8s/0.004s=450th sample & ~2.0s/0.004s=500th sample
% =30ms window
pref1=zeros(ns,ncmp);
sref1=zeros(ns,ncmp);
pref2=zeros(ns,ncmp);
sref2=zeros(ns,ncmp);
pref3=zeros(ns,ncmp);
sref3=zeros(ns,ncmp);
pref4=zeros(ns,ncmp);
sref4=zeros(ns,ncmp);
pref5=zeros(ns,ncmp);
sref5=zeros(ns,ncmp);
pddref=zeros(ns,ncmp);
sddref=zeros(ns,ncmp);

%start_cmp=202;
for ik=1:1:ncmp
    Dp=zeros(ns,ntrace);
    B1=zeros(ns,ntrace);     %15Hz
    B2=zeros(ns,ntrace);     %10Hz
    B3=zeros(ns,ntrace);     %20Hz
    B4=zeros(ns,ntrace);     %30Hz
    B5=zeros(ns,ntrace);     %40Hz

    [Dp, actual_ntrace]=favo_readsgy(infile, (ik-1)+ start_cmp , ntrace);
    [B1, actual_ntrace]=favo_readsgy(infile_f{1}, (ik-1)+ start_cmp, ntrace);
    [B2, actual_ntrace]=favo_readsgy(infile_f{2}, (ik-1)+ start_cmp, ntrace);
    [B3, actual_ntrace]=favo_readsgy(infile_f{3}, (ik-1)+ start_cmp, ntrace);
    [B4, actual_ntrace]=favo_readsgy(infile_f{4}, (ik-1)+ start_cmp, ntrace);
    [B5, actual_ntrace]=favo_readsgy(infile_f{5}, (ik-1)+ start_cmp, ntrace);

    if (actual_ntrace==ntrace)
        B1=B1*mtpseis+0.01;
        B2=B2*mtpseis+0.01;
        B3=B3*mtpseis+0.01;
        B4=B4*mtpseis+0.01;
        B5=B5*mtpseis+0.01;

        D1b=zeros(ns,ntrace);
        D2b=zeros(ns,ntrace);
        D3b=zeros(ns,ntrace);
        D4b=zeros(ns,ntrace);
        D5b=zeros(ns,ntrace);

        for i=1:ntrace;
            m1(i)=0;m2(i)=0;m3(i)=0;m4(i)=0;m5(i)=0;
            for j=win_start:win_end;
                m1(i) = m1(i)+B1(j,i)*B1(j,i);    %max(B1(j,i));
                m2(i) = m2(i)+B2(j,i)*B2(j,i);    %max(B2(j,i));
                m3(i) = m3(i)+B3(j,i)*B3(j,i);    %max(B3(j,i));
                m4(i) = m4(i)+B4(j,i)*B4(j,i);    %max(B4(j,i));
                m5(i) = m5(i)+B5(j,i)*B5(j,i);    %max(B5(j,i));
            end
            m1(i)=sqrt(m1(i)/(win_end-win_start+1));
            m2(i)=sqrt(m2(i)/(win_end-win_start+1));
            m3(i)=sqrt(m3(i)/(win_end-win_start+1));
            m4(i)=sqrt(m4(i)/(win_end-win_start+1));
            m5(i)=sqrt(m5(i)/(win_end-win_start+1));
        end
        
%         for i=2:ntrace; %give the mute data with the value of previous trace 
%              if (i>mute_trace && m1(i)==0),m1(i)=m1(i-1);end
%              if (i>mute_trace && m2(i)==0),m2(i)=m2(i-1);end
%              if (i>mute_trace && m3(i)==0),m3(i)=m3(i-1);end
%              if (i>mute_trace && m4(i)==0),m4(i)=m4(i-1);end
%              if (i>mute_trace && m5(i)==0),m5(i)=m5(i-1);end
%         end

        for i=1:ntrace;
             a2IF(i)=m1(i)/m2(i);
             a3IF(i)=m1(i)/m3(i);
             a4IF(i)=m1(i)/m4(i);
             a5IF(i)=m1(i)/m5(i);
        end

        for i=1:ntrace;
             for j=1:ns;
                D1b(j,i)=B1(j,i);
                D2b(j,i)=a2IF(i)*B2(j,i);
                D3b(j,i)=a3IF(i)*B3(j,i);
                D4b(j,i)=a4IF(i)*B4(j,i);
                D5b(j,i)=a5IF(i)*B5(j,i);
             end
        end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%% INVERSION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        dd=zeros(ntrace,1);
        bb1=zeros(ntrace,1);
        bb2=zeros(ntrace,1);
        bb3=zeros(ntrace,1);
        bb4=zeros(ntrace,1);
        bb5=zeros(ntrace,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        sk=ntrace*(nfrq-1);
        RR=zeros(sk,1);    %240=������45��*��Ƶ����-1����4��
        RM=zeros(sk,2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        plfref=zeros(ns,1);
        pdd2ref=zeros(ns,1);
        slfref=zeros(ns,1);
        %RR2=zeros(300,1);   %����*Ƶ����
        %RM2=zeros(300,4);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        A=zeros(ntrace,2);
        m=zeros(2,1);
        md=zeros(2,1);
        md2=zeros(4,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% inversion for 1 time-sample but ALL offsets
       %t=1;
        for t=start_point:ns;    %calcute from the data not be muted
            i=1;
            for i=1:ntrace;
                dd(i,1)=Dp(t,i);
                bb1(i,1)=D1b(t,i);
                bb2(i,1)=D2b(t,i);
                bb3(i,1)=D3b(t,i);
                bb4(i,1)=D4b(t,i);
                bb5(i,1)=D5b(t,i);
            end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            i=1;
            for i=1:ntrace
                A(i,1)=(5/8);
                A(i,1)=A(i,1)-0.5*((svel(t,i)^2)/(pvel(t,i)^2))*(sin(theta(t,i))^2);
                A(i,1)=A(i,1)+0.5*(tan(theta(t,i))^2);
            end
  
            i=1;
            for i=1:ntrace
                A(i,2)=-4*((svel(t,i)^2)/(pvel(t,i)^2))*(sin(theta(t,i))^2);
            end
%%%%%%%%%%% Full Elastic Inversion %%%%%%%%%%%
% least squares solution
            m=inv(A'*A)*A'*dd;
            pref(t,ik)=m(1);
            sref(t,ik)=m(2);
  
%%%%%%%%%%% Spec Decom Inversion %%%%%%%%%%%
% least squares solution for 10Hz 
            m=inv(A'*A)*A'*bb2;
            pref2(t,ik)=m(1);
            sref2(t,ik)=m(2);

% least squares solution for 20Hz 
            m=inv(A'*A)*A'*bb3;
            pref3(t,ik)=m(1);
            sref3(t,ik)=m(2);

% least squares solution for 30Hz 
            m=inv(A'*A)*A'*bb4;
            pref4(t,ik)=m(1);
            sref4(t,ik)=m(2);

% least squares solution for 40Hz 
            m=inv(A'*A)*A'*bb5;
            pref5(t,ik)=m(1);
            sref5(t,ik)=m(2);

% least squares solution for 15Hz 
            m=inv(A'*A)*A'*bb1;
            pref1(t,ik)=m(1);
            sref1(t,ik)=m(2); 
  
%%%%%%%%%%% Dispersion Inversion
% use F 15Hz solution in the calculation
            for i=1:ntrace
                 j=ntrace+i;
                 k=ntrace*2+i;
                 l=ntrace*3+i;
                 RR(i,1)=bb2(i)-(A(i,1)*m(1))-(A(i,2)*m(2));
                 RR(j,1)=bb3(i)-(A(i,1)*m(1))-(A(i,2)*m(2));
                 RR(k,1)=bb4(i)-(A(i,1)*m(1))-(A(i,2)*m(2));
                 RR(l,1)=bb5(i)-(A(i,1)*m(1))-(A(i,2)*m(2));
            end

            for i=1:ntrace
                j=ntrace+i;
                k=ntrace*2+i;
                l=ntrace*3+i;
                RM(i,1)=(frq(2)-frq(1))*A(i,1);     %10-15
                RM(j,1)=(frq(3)-frq(1))*A(i,1);     %20-15
                RM(k,1)=(frq(4)-frq(1))*A(i,1);     %30-15
                RM(l,1)=(frq(4)-frq(1))*A(i,1);     %40-15
                RM(i,2)=(frq(2)-frq(1))*A(i,2);
                RM(j,2)=(frq(2)-frq(1))*A(i,2);
                RM(k,2)=(frq(2)-frq(1))*A(i,2);
                RM(l,2)=(frq(2)-frq(1))*A(i,2);
            end
% least squares solution  
            md=inv(RM'*RM)*RM'*RR;
            pddref(t,ik)=md(1);
            sddref(t,ik)=md(2);
%         if isnan(pddref(t,ik))==1
%             pddref(t,ik)=pddref(t,ik-1);
%         end
        end
    elseif(actual_ntrace<ntrace) 
        pddref(:,ik)=0; sddref(:,ik)=0;
    end
    per=ik/ncmp*100;
    if(rem(ik,50)==0)
       per1=num2str(per);
       per2=strcat(per1,'% is calculated!');
       fprintf('%s\n',per2);
   end
 end

GrdFile1 = strrep(infile, '.sgy', '_pd2.grd');
%GrdFile2 = strrep(infile, '.sgy', '_theta.grd');

tmin=(0-ns+1)*dt;
tmax=0;
fmin=start_cmp;
fmax=start_cmp+(ncmp-1);
pddref=abs(flipud(pddref));

theta1=flipud(theta1);

WriteGrd(pddref,GrdFile1,fmin,fmax,tmin,tmax);
%WriteGrd(theta1,GrdFile2,fmin,f1max,tmin,tmax);
