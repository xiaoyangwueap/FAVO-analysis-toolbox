function [] = draw_sgywaveform(infile, start_time, end_time, scale)
%  This function is used to draw the waveform of a .sgy file generated from 
%  Seismic Unix; the .sgy file contains one CDP gather.
%
%  infile: filename of the one gather .sgy;
%  start_time: start time position to be drawn;
%  end_time: end time position to be drawn;
%  scale: controlling the area of waveform.
%
%  Example:
%        infile = 'D:\MATLAB\R2008a\work\favo\data\example4\1800.sgy';
%        start_time = 1.2; 
%        end_time = 1.6;
%        draw_sgywaveform(infile, start_time, end_time,1000);
%
%  20 Jun 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

if (exist(infile) == 0),
    error('input files dont exist, please check!');
end

[Data,SegyTraceHeaders,SegyHeader,HeaderInfo]=ReadSegy(infile);
dt = SegyHeader.dt/1000000;
ns = SegyHeader.ns;
offset = HeaderInfo.offset;
ds =offset(3)-offset(2);
ntrace = length(offset)
start_sample = floor(start_time/dt);
end_sample = floor(end_time/dt);

Dshow=Data(start_sample:end_sample, 1:ntrace);
x=offset;                           %length of x must be the same as Dshow
y=[start_time:dt:end_time];         %length of y must be the same as Dshow
%figure, %subplot(3,1,1),hold on;
wigb_m(Dshow,0.10,x,y,scale,[0 0 0],1);
xlabel('offset(m)');
%title('(a)Class III AVO');
ylabel('Time (second)');
xlim([offset(1)-ds offset(ntrace)+ds]);
ylim([start_time end_time]);
set(gca,'YTick',[start_time:50*dt:end_time]);