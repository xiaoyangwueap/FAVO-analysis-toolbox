function [data_b] = spectral_balance_prestack(infile, ntrace, frq, tb,tp);
%  [data_b] = spectral_balance_prestack(infile, ntrace, frq, tb,tp) 
%  calculates the balanced spectral amplitude for prestack CMP gather.
%  
%  input:
%  infile:input .sgy file storing the segy seismic data, the .sgy files
%         that store spectral amplitude should also be prepared in the same 
%         directory with the filename format ending with '_10Hz.sgy' 
%  ntrace: number of trace in the .sgy file
%  frq:frequecy-sections for spectral balance, first one must be the
%      reference frequency, others must be sorted in ascending order. 
%       Usually we select 4 or 5 frequencies for spectral balance.
%  tb: time for balance. unit:second
%  tp: time for picking out the spectral amplitude. unit:second
%
% output:
%    data_b: three-dimension array storing the balanced spectral ampllutude
%    at each frequency for each trace at each time position.
%
%  Example:
%  infile = 'D:\MATLAB\R2008a\work\favo\data\example4\1800.sgy';
%  frq = [30 10 20 40];
%  ntrace = 29;
%  tb = 0.9;
%  tp = 1.4;
%  spectral_balance_prestack(infile, ntrace, frq, tb, tp);
%  
%  29 Jun 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

if (nargin <=4 || nargin > 6),
    error('5 parameters are required.');
end;

nfrq = length(frq);           %Number of frequencies
if (nfrq ~= 4 && nfrq ~= 5),
    error('the number of frequencies should be 4 or 5.');
end;

infile_sgy = cell(nfrq,1);    %files that store the .sgy data to be balanced, must be in the same directory as infile
outfile_sgy = cell(nfrq,1);   %files that store the balanced .sgy data, must be in the same directory as infile
offset = 100:50:1500;         %%%%offset, should be modified according to segy header.

for i=1:ntrace
    time(i)=tb;
end

sgy3200 = zeros(1600,1, 'uint16');
sgy400 = zeros(200,1, 'uint16');
sgyhead = zeros(120,ntrace, 'int16');
m = zeros(ntrace,nfrq);

for i = 1:nfrq
    a = strcat('_', num2str(frq(i)), 'Hz.sgy');
    b = strcat('_', num2str(frq(i)), 'Hzb.sgy');
    infile_sgy{i} = strrep(infile, '.sgy', a);     %replace '.sgy' in infile with string a;
    index = exist(infile_sgy{i},'file');
    if (index == 0),
        error('Segy file does not exist,please check!');
    end
    outfile_sgy{i} = strrep(infile, '.sgy', b);    %files for output;
end

[da, dt, ns, sgy3200, sgy400, sgyhead] = readmysegy(infile_sgy{1}, ntrace);
data = zeros(ns, ntrace, nfrq, 'single');
data_b = zeros(ns, ntrace, nfrq, 'single');

for i = 1:nfrq
    data(:,:,i) = readmysegy(infile_sgy{i}, ntrace);
end

nt = floor(time/dt);    %sample point position for balance
pt = floor(tp/dt);      %sample point position for picking out amplitude
t_win = 10;             %sample point window for calculating the RMS amplitude when balancing
t_win2 =5;              %sample point window for calculating the average amplitude

for i = 1:nfrq
    for j = 1:ntrace
        s=data(:,j,i);
        for k = nt(i)-t_win:nt(i)+t_win;
            m(j,i) = m(j,i)+s(k)*s(k);
        end
        m(j,i)=sqrt(m(j,i)/(2*t_win+1));
    end
end

for i = 1:nfrq
    for j = 1:ntrace
        aIF(j,i)=m(j,1)/m(j,i);
    end
end

for i = 1:nfrq
    for j=1:ntrace
         for k=1:ns;
             data_b(k,j,i)=data(k,j,i)*aIF(j,i);
         end
    end
end

for i = 1:nfrq
    writemysegy(outfile_sgy{i}, ntrace, sgy3200, sgy400, sgyhead, data_b(:,:,i));
end

if (nfrq == 4),
    ss30 = mean(data_b(342:352,:,1))/100; ss10 = mean(data_b(342:352,:,2))/100;    %should be modified according the sequence of frq
    ss20 = mean(data_b(342:352,:,3))/100; ss40 = mean(data_b(342:352,:,4))/100;
    
    plot(offset, ss10,'r+'),hold on,plot(offset, ss20,'g*'),hold on
    plot(offset, ss30,'bo'),hold on,plot(offset, ss40,'ks'),hold on
    plot(offset, ss10,'r'),hold on,plot(offset, ss20,'g'),hold on
    plot(offset, ss30,'b'),hold on,plot(offset, ss40,'k')
    
    legend('10Hz','20Hz','30Hz','40Hz','10Hz','20Hz','30Hz','40Hz');
    ss10=ss10'; ss20=ss20'; ss30=ss30'; ss40=ss40';
    ssk(:,1)=ss10;ssk(:,2)=ss20;ssk(:,3)=ss30;ssk(:,4)=ss40;
end

if (nfrq == 5),
    ss30 = mean(data_b(pt-t_win2:pt+t_win2,:,1))/100; ss10 = mean(data_b(pt-t_win2:pt+t_win2,:,2))/100;   %should be modified according the sequence of frq
    ss20 = mean(data_b(pt-t_win2:pt+t_win2,:,3))/100; ss40 = mean(data_b(pt-t_win2:pt+t_win2,:,4))/100;
    ss50 = mean(data_b(pt-t_win2:pt+t_win2,:,5))/100;
    
    plot(offset, ss10,'r+'),hold on,plot(offset, ss20,'g*'),hold on
    plot(offset, ss30,'bo'),hold on,plot(offset, ss40,'ks'),hold on
    plot(offset, ss50,'cd');
    plot(offset, ss10,'r'),hold on,plot(offset, ss20,'g'),hold on
    plot(offset, ss30,'b'),hold on,plot(offset, ss40,'k'),hold on
    plot(offset, ss50,'c'); 
    
    legend('10Hz','20Hz','30Hz','40Hz','50Hz','10Hz','20Hz','30Hz','40Hz','50Hz');
    ss10=ss10'; ss20=ss20'; ss30=ss30'; ss40=ss40'; ss50=ss50';
    ssk(:,1)=ss10;ssk(:,2)=ss20;ssk(:,3)=ss30;ssk(:,4)=ss40;ssk(:,5)=ss50;
end



    
    