function [ga,peakfrq,gradient,bandwidth] = freqcurve(trace, th, dt, frq, winT, winF)
%  this program is used to calculate frequency curve for a single trace at 
%  a temporal position.
%
%  input:
%      trace: a trace of seismic signal
%      th: the time position for average spectral amplitude calculation, unit:second
%      dt: sampling space,unit:second
%      frq: frequencies for spectral decomposition
%      winT: time window length(ms), equal to wavelet length
%      WinF: frequency window(ms), equal to 2*winT
%
%  output:
%      ga: one-dimension array storing spectral amplitude at each frequency
%      peakfrq: peak frequency of the curve
%      gradient:gradient of the curve
%      bandwidth: bandwidth of the curve
%
%  Example:
%  infile = 'D:\MATLAB\R2008a\work\favo\data\Example6\trace.dat';
%  trace = load(infile);
%  [ga, peakfrq, gradient, bandwidth] = freqcurve(trace, 1.12, 2/3000, 1:1:100);
%  
%  6 July 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

if (nargin <= 1),
    error('At least 3 parameter is required');
elseif (nargin == 3),
    frq = 1:1:60; winT = 30; winF = 60; 
elseif (nargin == 4),
    winT = 30; winF = 60; 
elseif (nargin == 5),
    winF = 60;
end

[mm, nn] = size(trace);
if (nn == 1),
    s = trace;
elseif (mm == 1),
    s = trace';
end

ns = length(s);
nfrq = length(frq);
ga(nfrq) = 0;            %storing the spectral amplitude at corresponding frequencies

sigma1 = 0.18;
sigma2 = 0.36;
k1 = exp(-1/(2*sigma1^2));        %sigma in gaussian function
k2 = exp(-1/(2*sigma2^2));
gLength = round(winT/(dt*1e3));
if (rem(gLength, 2) == 0),
    gLength = gLength+1;
end
hLength = round(winF/(dt*1e3));
if (rem(hLength, 2) == 0),
    hLength = hLength+1;
end

g = window_m(gLength, 'gauss', k1);
h = window_m(hLength, 'gauss', k2);

th = floor((th)/dt);
w(ns,nfrq) = 0;
absw(ns,nfrq) = 0;
f = [0:(ns-1)/2]'/(ns*dt*2);
t = [0:ns-1]'*dt;
M = length(t);
N = length(f);

NN(nfrq) = 0;
for i = 1:1:nfrq
    for k = 1:N-1
        if (frq(i) >= f(k)&&frq(i) < f(k+1))
            NN(i) = k;
            break;
        end
    end
end
   
[w1,t1,f1] = tfrspwv_m(hilbert(s),dt,g,h);   %Gauss window

for i = 1:nfrq
    w(:,i) = w1(:,NN(i));
    absw(:,i) = abs(w(:,i));
    ga(i) = max(absw(th-10:th+10,i));
end

figure, plot(frq,ga,'r','LineWidth',2);
xlabel('Frequency/Hz');
ylabel('Amplitude');
%save data.dat ga  -ascii;

path = pwd;
outfile = strcat(path, '\favo\data\Example6\fc.dat');
fid = fopen(outfile,'w');
for i = 1:nfrq
    fprintf(fid,'%f %f', frq(i), ga(i));
    fprintf(fid,'\n');
end
fclose(fid);

%calculating the attribute of the frequency curve;
%max1:peak value; peakfrq:peak frequency; gradient, bandwidth

max1 = max(ga(:)); max2 = max1*0.85; max3 = max1*0.55; max4 = max1*0.25;     %Attenuation gradient
for i=1:ns
    if (ga(i)==max1),peakfrq=frq(i);break;end;
end
        
for i=1:ns-1
    if (frq(i)>peakfrq && ga(i)<=max2),frq1=frq(i);break;end;
end
for i=1:ns-1
    if (frq(i)>peakfrq && ga(i)<=max3),frq2=frq(i);break;end;
end
gradient=(max2-max3)/(frq2-frq1);
        
for i=1:ns-1
    if (frq(i)<peakfrq && ga(i)>=max4),frq3=frq(i);break;end;
end
for i=1:ns-1
    if (frq(i)>peakfrq && ga(i)<=max4),frq4=frq(i);break;end;
end
bandwidth=abs(frq3-frq4);
