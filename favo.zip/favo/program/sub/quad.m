function [xr, xi, yr, yi] = quad(ar, ai, br, bi, cr, ci)

%  this is a double precision programme for solving the complex
%  valued quadratic equation az^2 + bz + c =0
%  inputs are a=(ar,ai) etc. no ordering applied to the roots.
%  written by mark chapman, mchapman@staffmail.ed.ac.uk, 2004. 
%  changed to matlab by Xiaoyang Wu, 28 Jun,2012, xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

%  calculate square root of discriminant

       temp1 = br*br + (-1)*bi*bi + (-1)*4*ar*cr + 4*ai*ci;
       temp2 = 2*br*bi + (-4)*ar*ci + (-4)*ai*cr;
       [dr, di] = square(temp1, temp2);


% calculate q value, following numerical recipes p.178

       if ( (br*dr + bi*di) >= 0 ),
          qr = br + dr;
          qr = -0.5*qr;
          qi = bi + di;
          qi = -0.5*qi;
        else
          qr = br - dr;
          qr = -0.5*qr;
          qi = bi - di;
          qi = -0.5*qi;
       end


%  now calculate roots

       temp1 = ar*ar + ai*ai;
       xr = (qr*ar + qi*ai)/temp1;
       xi = (-1*qr*ai + qi*ar)/temp1;

       temp2 = qr*qr + qi*qi;
       yr = (cr*qr + ci*qi)/temp2;
       yi = (ci*qr - cr*qi)/temp2;
       
       