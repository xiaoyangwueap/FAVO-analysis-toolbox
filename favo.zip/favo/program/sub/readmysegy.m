function [sgydata, dt, ns, sgy3200, sgy400, sgyhead] = readmysegy(infile, ntrace);
%  [sgydata, dt, ns, sgy3200, sgy400, sgyhead] = Readmysegy(infile, ntrace)
%  is suitable for reading .sgy file with small volume.
%  
%  input:
%  infile: input .sgy file storing a 2D seismic data;
%  ntrace: number of traces in .sgy file;
%
%  output:
%  sgydata: frequencies for spectral decomposition;
%  dt: sample spacing (unit: second);
%  ns: number of samples per trace;
%  sgy3200: 3200 bytes of the sgy header;
%  sgy400: 400 bytes of the sgy header;
%  sgyhead: the trace header for all the traces.
%
%  Example:
%       infile = 'D:\MATLAB\R2008a\work\favo\data\example2\IL1605.sgy';
%       ntrace = 141;
%       [sgydata,dt,ns,sgy3200,sgy400,sgyhead] = readmysegy(infile, ntrace);
%
%  6 July 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

if (nargin <=1),
    error('2 parameters are required.');
end;

i = exist(infile,'file');
if (i == 0),
    error('Segy file does not exist,please check!');
end

sgy3200 = zeros(1600,1, 'uint16');
sgy400 = zeros(200,1, 'uint16');

fidin = fopen(infile,'r','ieee-be');
sgy3200 = fread(fidin, 1600, 'uint16');
sgy400 = fread(fidin, 200, 'uint16');
ns = sgy400(11);
dt = sgy400(9)/1000000;
segy_format = sgy400(13);

sgyhead = zeros(120,ntrace, 'int16');
sgydata = zeros(ns, ntrace, 'single');
switch segy_format
    case 1
         sgytrace=zeros(ns, 1, 'uint32');     %IBM format
    case 5
         sgytrace=zeros(ns, 1, 'single');     %IEEE format
    otherwise
    return;
end

for ktrace = 1:ntrace
fseek(fidin , double(3200+400+(ktrace-1)*(ns*4+240) ),'bof');    %read from begin of file
sgyhead(:,ktrace) = fread(fidin, 120, 'int16');
    switch segy_format
        case 1
           sgytrace = fread(fidin, ns,'uint32');
           sgydata(:,ktrace) = single(ibm2ieee(sgytrace));
        case 5
           sgytrace = fread(fidin, ns,'single');
           sgydata(:,ktrace) = single(sgytrace);
        otherwise
    end
end
fclose(fidin);


