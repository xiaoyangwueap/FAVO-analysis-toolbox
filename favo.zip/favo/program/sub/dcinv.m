function [a, b] = dcinv(x, y)
%  this code inverts a 2X2 complex matrix, x+iy, where x and y are
%  2x2 double precision real matrices and returns the inverse
%  as a+ib, a and b being double precision 2X2 matrices. 
%
%  written by mark chapman, mchapman@staffmail.ed.ac.uk, 2004. 
%  changed to matlab by Xiaoyang Wu, 28 Jun,2012, xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey
[m1,n1] = size(x);
[m2,n2] = size(y);
if (m1 ~= 2 || n1 ~= 2 || m2 ~=  2 ||n2 ~= 2),
    error('a or b are not 2*2 matrix');
end

detr = x(1,1)*x(2,2) + (-1)*y(1,1)*y(2,2) + (-1)*x(1,2)*x(2,1) + y(1,2)*y(2,1);
deti = x(1,1)*y(2,2) + y(1,1)*x(2,2) + (-1)* x(1,2)*y(2,1) + (-1)*x(2,1)*y(1,2);
mr= detr/(detr*detr + deti*deti);
mi= (-1*deti)/(detr*detr + deti*deti);

       t1(1,1)= x(2,2);
       t1(1,2)= -1*x(1,2);
       t1(2,1)= -1*x(2,1);
       t1(2,2)= x(1,1);

       t2(1,1)= y(2,2);
       t2(1,2)= -1*y(1,2);
       t2(2,1)= -1*y(2,1);
       t2(2,2)= y(1,1);

       a(1,1)= mr*t1(1,1) - mi*t2(1,1);
       a(1,2)= mr*t1(1,2) - mi*t2(1,2);
       a(2,1)= mr*t1(2,1) - mi*t2(2,1);
       a(2,2)= mr*t1(2,2) - mi*t2(2,2);

       b(1,1)= mi*t1(1,1) + mr*t2(1,1);
       b(1,2)= mi*t1(1,2) + mr*t2(1,2);
       b(2,1)= mi*t1(2,1) + mr*t2(2,1);
       b(2,2)= mi*t1(2,2) + mr*t2(2,2);
