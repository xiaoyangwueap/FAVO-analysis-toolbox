function WriteGrd(x,GrdFile,tmin,tmax,fmin,fmax)
%  this function is used to write 2 dimension array as a .grd file, which
%  is recognized and drawn in surfer.
%
%  6 July 2012, Xiaoyang Wu, 
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

ss=size(x);
[fidGrd,msg] = fopen(GrdFile,'wt');
fprintf(fidGrd,'DSAA\n');
fprintf(fidGrd,'%d %d\n',ss(2),ss(1));      %s(1)=901,s(2)=513  x(901,513)
fprintf(fidGrd,'%d %e\n',tmin,tmax);
fprintf(fidGrd,'%d %e\n',fmin,fmax);
format short e
fprintf(fidGrd,'%e %e\n',min(min(x)),max(max(x)));
for i=1:ss(1)
    for j=1:ss(2)
        fprintf(fidGrd,' %e',x(i,j));
    end
    fprintf(fidGrd,'\n');
end
fclose(fidGrd);
format