function [out1,out2] = modmorlet(varargin)
%  Modified Morlet wavelet.
%  [out1,out2] = modmorlet(varargin) returns values of 
%  the Morlet wavelet on an N point regular grid 
%  in the interval [LB,UB].
%  Output arguments are the wavelet function PSI
%  computed on the grid X, and the grid X.
%  This wavelet has [-4 4] as effective support.
%
%  20 Jun 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey
%
% Check arguments.
if errargn(mfilename,nargin,[3 4],nargout,[0:2]), error('*'); end
m=10;
si=1;
tao=15;
c=3;

% Compute values of the Morlet wavelet.
out2 = linspace(varargin{1:3});        % wavelet support.
out1 = exp(i*m.*out2).*exp(-0.5*(c.*out2).^2)-sqrt(2)*exp(-m^2/(4*c^2)+i*m.*out2-(c.*out2).^2);
