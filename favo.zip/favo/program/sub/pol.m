function [er, ei] = pol(lamr, lami, mur, mui, r, s1, s3r, s3i)

% written by mark chapman, mchapman@staffmail.ed.ac.uk, 2004. 
% changed to matlab by Xiaoyang Wu, 28 Jun,2012, xywu@bgs.ac.uk
% Edinburgh Anisotropy Project
% British Geological Survey

% define the christoffel matrix.
ar = (lamr + 2*mur)*s1*s1 + mur*s3r*s3r + (-1)*mur*s3i*s3i + (-2)*mui*s3r*s3i - r;
ai = (lami + 2*mui)*s1*s1 + mui*s3r*s3r + (-1)*mui*s3i*s3i + 2*mur*s3r*s3i;
br = s1*s3r*(lamr + mur) + (-1)*s1*s3i*(lami + mui);
bi = s1*s3i*(lamr + mur) + s1*s3r*(lami + mui);
cr = br;
ci = bi;
dr = s1*s1*mur + (lamr + 2*mur)*s3r*s3r + (-1)*(lamr + 2*mur)*s3i*s3i + (-2)*(lami + 2*mui)*s3r*s3i - r;
di = s1*s1*mui + (lami + 2*mui)*s3r*s3r + (-1)*(lami + 2*mui)*s3i*s3i + 2*(lamr + 2*mur)*s3i*s3r;

% choose the row with the largest entries
norm1= (ar*ar + ai*ai + br*br + bi*bi);
norm2= (cr*cr + ci*ci + dr*dr + di*di);

% calculate polarisations
if (norm1 > norm2),
    er(1) = br;
    er(2) = -1*ar;
    ei(1) = bi;
    ei(2) = -1*ai;      
else
    er(1) = dr;
    er(2) = -1*cr;
    ei(1) = di;
     ei(2) = -1*ci;
end