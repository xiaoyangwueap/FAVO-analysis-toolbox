function  [cmp_data, actual_ntraces] = favo_readsgy(segy_filename, cmp_num, cmp_ntraces)
% favo_readsgy(segy_filename, cmp_num, cmp_ntraces) is a subroutine called
% by favo_spwv to read .segy data cmp by cmp. Each time the subroutine only
% read one cmp data for the calculation of favo attribute.
%
% segy_filename:the prestack seismic data for calculation of favo
% attribute;
% cmp_num: the NO. of cmp gather for input.
% cmp_ntraces: the number of traces for each cmp gather.
%
%  20 Jun 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey
% 
fdavo_extract_sgyhdr_hdi(segy_filename);
hdi_filename=strcat(segy_filename, '.hdi');
eval(['load ',hdi_filename,'  -mat']) ;

cmp_data=zeros(hdi_nsamples, cmp_ntraces);

sgy3200=zeros(3200,1,'uint8') ; 
sgy400=zeros(200,1,'uint16') ; 
sgyhead=zeros(120,1,'int16'); 

segyin_fid=fopen(segy_filename, 'r' ,'ieee-be' );
sgy3200=fread(segyin_fid, 3200, 'uint8'); 
sgy400=fread(segyin_fid, 200, 'uint16'); 
segy_fmt_code=sgy400(13);

switch sgy400(13)
    case 1 
           sgytrace=zeros(hdi_nsamples, 1, 'uint32') ;
    case 5
           sgytrace=zeros(hdi_nsamples, 1, 'single') ;
    otherwise 
            msgbox('wrong format code!') ;
     return; 
end


%ok_traces=find( (hdi_ffid==cmp_num ) ) ;            %xline  hdi_ffid corresponds cmp no.
ok_traces=find( (hdi_cdp==cmp_num ) ) ;              %inline hdi_cdp corresponds cmp no.
total_traces=length(ok_traces);
if(total_traces>cmp_ntraces) 
    total_traces=cmp_ntraces;
end
actual_ntraces=total_traces;

if (total_traces>0)
      
     double_location=double(hdi_location(ok_traces));
     
     for ntrace=1:1:total_traces  
         fseek(segyin_fid, double_location(ntrace) , 'bof');  
         sgyhead(:,1)=fread(segyin_fid,120,'int16');
      switch segy_fmt_code
        case 1 
          sgytrace(:,1)=fread(segyin_fid, hdi_nsamples,'uint32') ;
          sgytrace=single( ibm2ieee(sgytrace) );
        case 5
           sgytrace=fread(segyin_fid, hdi_nsamples, 'single');
          otherwise 
       end 
         cmp_data(:,ntrace)=double(sgytrace) ;
     end
            
end

  
fclose(segyin_fid) ; 
