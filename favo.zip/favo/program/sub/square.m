function [br, bi] = square(ar, ai)

%  this subroutine takes a complex number ar + i*ai and returns its
%  square root in the form br+i*bi. it follows the technique suggested
%  on page 172 of numerical recipes. 
%
%  written by mark chapman, mchapman@staffmail.ed.ac.uk, 2004. 
%  changed to matlab by Xiaoyang Wu, 28 Jun,2012, xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

    if ( ar < (-1e-8) && abs(ai) < (1e-8) ),
        br=0;
        bi=sqrt(abs(ar));
    else
        if ( abs(ar) < (1e-8) && abs(ai) < (1e-8) ),
           w=0;   
        else
            if ( abs(ar) >= abs(ai)),
                temp1= 1 + sqrt(1 + (ai*ai)/(ar*ar));
                temp1= sqrt( 0.5* temp1);
                temp2= sqrt(abs(ar));
                w= temp1*temp2;
             else
                temp1= sqrt(1 + (ar*ar)/(ai*ai) );
                temp1= abs(ar/ai) + temp1;
                temp1= sqrt(0.5*temp1);
                temp2= sqrt(abs(ai));
                w= temp1*temp2;
             end
        end


        if ( abs(w) < 1e-8),
           br=0;
           bi=0;
        else 
             if (ar >= 0),
                 br=w;
                 bi=(ai/(2*w));
             else
                 if (ai >= 0),
                    br=abs(ai)/(2*w);
                    bi=w;
                 end
               if (ai < 0),
                 br=abs(ai)/(2*w);
                 bi=-1*w;
               end
           end 
        end 
       end 
