function [tfrx,t,f] = tfrstft_m(x,htype,hlength,dt);
%	This function computes the short-time Fourier transform of a 
%   discrete-time signal X.
%   
%   input:
%	x      : signal
%	htype  : frequency smoothing window, H being normalized so as to
%	         be  of unit energy.      (default : Hamming(N/4))
%   hlength: the length of frequency smoothing window
%	dt     : time sampling interval
%
%   output:
%	tfrx   : time-frequency decomposition (complex values). 
%   t      : time sampling series(unit:s)
%   f      : frequency bins(unit:Hz)

[xrow,xcol] = size(x);
if (nargin < 1),error('At least 1 parameter is required');end
if (xcol ~= 1 && xrow ~= 1),
    error('x must have only one row or one column, please check!');
elseif (xrow == 1),
    x=x';[xrow,xcol] = size(x);
end

N=xrow;
t=1:xrow;

if (nargin == 1),
     htype= 3;hlength=floor(N/4);dt=0.001;
elseif (nargin == 2),
    hlength=floor(N/4); dt=0.001;
elseif (nargin == 3),
    dt=0.001;
end;

hlength=hlength+1-rem(hlength,2);   %hlength must be a odd number
 
 %------------------- define type of window function  --------------------
 if(htype==0),h=window(@hamming,hlength);             %htype=0 Hamming window
 elseif(htype==1),h=window(@hann,hlength);            %htype=1 Hanning window
 elseif(htype==2),h=window(@gausswin,hlength);        %htype=2 Gauss window
 elseif(htype==3),h=window(@nuttallwin,hlength);      %htype=3 Nuttall window
 end
 %------------------- define type of window function  --------------------
 
 
if (N<0),
 error('N must be greater than zero');
end;
[trow,tcol] = size(t);
if (xcol~=1),
 error('X must have one column');
elseif (trow~=1),
 error('T must only have one row'); 
%elseif (2^nextpow2(N)~=N),
%fprintf('For a faster computation, N should be a power of two\n');
end; 

[hrow,hcol]=size(h); Lh=(hrow-1)/2; 
if (hcol~=1)|(rem(hrow,2)==0),
 error('H must be a smoothing window with odd length');
end;

h=h/norm(h);

tfr= zeros (N,tcol) ;  
for icol=1:tcol,
 ti= t(icol); tau=-min([round(N/2)-1,Lh,ti-1]):min([round(N/2)-1,Lh,xrow-ti]);
 indices= rem(N+tau,N)+1; 
 tfr(indices,icol)=x(ti+tau,1).*conj(h(Lh+1+tau));
end;
tfr=fft(tfr); 

if (nargout==0),
 return;
elseif (nargout==3),
    tfr=abs(tfr);
    tfr=tfr';
  if rem(N,2)==0, 
   f=[0:N/2-1]'/(N*dt);
   t=[0:N-1]'*dt;
   tfrx(1:N,1:N/2)=tfr(1:N,1:N/2);
else
  f=[0:(N-1)/2]'/(N*dt);
  t=[0:N-1]'*dt;
  tfrx(1:N,1:(N+1)/2)=tfr(1:N,1:(N+1)/2);
 end;
end;
