function [x, y] = dcmult(a, b, u, v)
%  this subroutine takes in 2X2 complex matrices (a+ib)
%  and (u+iv), double precision and returns the product
%  (a+ib)(u+iv) = (x+iy).
%
%  written by mark chapman, mchapman@staffmail.ed.ac.uk, 2004. 
%  changed to matlab by Xiaoyang Wu, 28 Jun,2012, xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

[m1,n1] = size(a);
[m2,n2] = size(b);

t1 = zeros(2,2);
t2 = zeros(2,2);

if (m1 ~= 2 || n1 ~= 2 || m2 ~=  2 ||n2 ~= 2),
    error('a or b are not 2*2 matrix');
end

[m1,n1]=size(u);
[m2,n2]=size(v);
if (m1 ~= 2 || n1 ~= 2 || m2 ~=  2 ||n2 ~= 2),
    error('a or b are not 2*2 matrix');
end

        t1 = rmult(a, u);
        t2 = rmult(b, v);
        x = rsubt(t1, t2);

        t1 = rmult(a, v);
        t2 = rmult(b, u);
        y = radd(t1, t2);