function insert=favo_insert(in,aoffset, tmpoffset)
%  favo_insert(segy_filename, cmp_num, cmp_ntraces) is a subroutine called
%  by favo_interpolate to interpolate segy files with varying offsets for
%  each cmp gather.
%
%  20 Jun 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

maxoffset=aoffset(end);
minoffset=aoffset(1);
ntrace=length(aoffset);

[tmp,kindex]=min(abs(aoffset-tmpoffset));
kk=kindex(1);
if (kk==1)
    insert=in(:,1); % extend outside
    return;
end

if (kk==length(aoffset))
   insert=in(:,end); % extend  outside
   return;
end

k0=kk-1;
k1=kk+1;
insert=0.15*in(:,k0)+0.7*in(:,kk)+0.15*in(:,k1); % insert ,inside , you can change the insert method yourself.
return
end
