function x=ReadGrd(GrdFile)
if errargn(mfilename,nargin,[1],nargout,[0:1]), error('*'), end
if errargt(mfilename,GrdFile,'str'), error('*'), end

[fidGrd,msg] = fopen(GrdFile,'rt');
head=fscanf(fidGrd,'%s',[1 1]);
size=fscanf(fidGrd,'%d',[1 2]);   %sizeΪ��ά����
xlimit=fscanf(fidGrd,'%f',[1 2]);
ylimit=fscanf(fidGrd,'%f',[1 2]);
zlimit=fscanf(fidGrd,'%f',[1 2]);
for i=1:size(2)
    for j=1:size(1)
        x(i,j)=fscanf(fidGrd,'%f',[1 1]);
    end
end
fclose(fidGrd);