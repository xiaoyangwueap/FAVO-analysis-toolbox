function [] = writemysegy(outfile, ntrace, sgy3200, sgy400, sgyhead, sgydata);
% [] = Writemysegy(outfile, sgydata, ntrace, sgy3200, sgy400, sgyhead) write
% .sgy files in IEEE format.

%  6 July 2012, Xiaoyang Wu, 
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey

if (nargin <=5),
    error('6 parameter are required.');
end

sgy400(13) = 5;
fidout = fopen(outfile, 'w','ieee-be');
fwrite(fidout, sgy3200, 'uint16');
fwrite(fidout, sgy400, 'uint16');

for i = 1:ntrace
    fwrite(fidout, sgyhead(:,i), 'int16');
    fwrite(fidout, single(sgydata(:,i)), 'single');
end
    
fclose(fidout);
