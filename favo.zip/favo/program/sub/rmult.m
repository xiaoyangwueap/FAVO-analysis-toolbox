function c = rmult(a, b)

% written by mark chapman, mchapman@staffmail.ed.ac.uk, 2004. 
% changed to matlab by Xiaoyang Wu, 28 Jun,2012, xywu@bgs.ac.uk
% Edinburgh Anisotropy Project
% British Geological Survey

[m1,n1]=size(a);
[m2,n2]=size(b);
if (m1 ~= 2 || n1 ~= 2 || m2 ~=  2 ||n2 ~= 2),
    error('a or b are not 2*2 matrix');
end

       c(1,1) = a(1,1)*b(1,1) + a(1,2)*b(2,1);
       c(1,2) = a(1,1)*b(1,2) + a(1,2)*b(2,2);
       c(2,1) = a(2,1)*b(1,1) + a(2,2)*b(2,1);
       c(2,2) = a(2,1)*b(1,2) + a(2,2)*b(2,2);