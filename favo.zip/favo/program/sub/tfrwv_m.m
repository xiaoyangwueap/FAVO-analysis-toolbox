function [tfrx,t,f] = tfrwv_m(x,dt);
%	[TFRX,T,F]=TFRWV_M(X,DT) computes the Wigner-Ville distribution
%	of a discrete-time signal X, 
%	or the cross Wigner-Ville representation between two signals. 
%    
%   input:
%	X     : signal if auto-WV, or [X1,X2] if cross-WV.
%   DT    : time sampling rate
%
%   output:
%	TFRX  : time-frequency representation of X
%   t      : time sampling series(unit:s)
%   f      : frequency bins(unit:Hz)

[xrow,xcol] = size(x);
if (nargin < 1),error('At least 1 parameter is required');end
if (xcol ~= 1 && xrow ~= 1),
    error('x must be one row or one column, please check!');
elseif (xrow == 1),
    x=x';[xrow,xcol] = size(x);
end

N=xrow;
t=1:xrow;

if (nargin == 1), dt=0.001;end

if (N<0),
 error('N must be greater than zero');
end;

[trow,tcol] = size(t);
if (xcol==0)|(xcol>2),
 error('X must have one or two columns');
elseif (trow~=1),
 error('T must only have one row'); 
%elseif (2^nextpow2(N)~=N),
%fprintf('For a faster computation, N should be a power of two\n');
end; 

tfr= zeros (N,tcol);  
for icol=1:tcol,
 ti= t(icol); taumax=min([ti-1,xrow-ti,round(N/2)-1]);
 tau=-taumax:taumax; indices= rem(N+tau,N)+1;
 tfr(indices,icol) = x(ti+tau,1) .* conj(x(ti-tau,xcol));
 tau=round(N/2); 
 if (ti<=xrow-tau)&(ti>=tau+1),
  tfr(tau+1,icol) = 0.5 * (x(ti+tau,1) * conj(x(ti-tau,xcol))  + ...
                           x(ti-tau,1) * conj(x(ti+tau,xcol))) ;
 end;
end; 
tfr= fft(tfr); 
if (xcol==1), tfr=real(tfr); end ;

if (nargout==0),
 return;
elseif (nargout==3),
 tfr=abs(tfr);
    tfr=tfr';
  if rem(N,2)==0, 
   f=[0:N/2-1]'/(N*dt*2);
   t=[0:N-1]'*dt;
   tfrx(1:N,1:N/2)=tfr(1:N,1:N/2);
else
  f=[0:(N-1)/2]'/(N*dt*2);
  t=[0:N-1]'*dt;
  tfrx(1:N,1:(N+1)/2)=tfr(1:N,1:(N+1)/2);
 end;
 
end;
