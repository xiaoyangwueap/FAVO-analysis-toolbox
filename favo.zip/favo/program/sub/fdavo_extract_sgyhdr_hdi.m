function status=fdavo_extract_sgyhdr_hdi(data_filename)
% status = fdavo_extract_sgyhdr_hdi(segy_filename, cmp_num, cmp_ntraces) is
% a subroutine called by favo_interpolate & favo_readsgy to extract the 
% header of segy file.
%
%  20 Jun 2012, Xiaoyang Wu
%  xywu@bgs.ac.uk
%  Edinburgh Anisotropy Project
%  British Geological Survey
%
status = -1 ;
hdi_filename = strcat(data_filename,'.hdi') ;
if (2 == exist(hdi_filename)) 
     status = 1; 
     return ; 
end

sgy3200 = zeros(3200,1,'uint8') ; 
sgy400 = zeros(200,1,'uint16') ; 

tic 
fid1 = fopen(data_filename,'r','ieee-be');
sgy3200 = fread(fid1, 3200, 'uint8'); 
sgy400 = fread(fid1, 200, 'uint16'); 
nsamples = sgy400(11) ;
dt = sgy400(9)/1000 ;

hdi_nsamples = nsamples; 
hdi_dt = dt; 

sgyhead_1bytes = zeros(240,1,'uint8') ; 
sgyhead_2bytes = zeros(120,1,'uint16') ; 
sgyhead_4bytes = zeros(60,1,'int32') ; 

fseek(fid1,3600,'bof');
filestat = dir(data_filename);
filelen = filestat.bytes;

total_traces = (filelen-3600)/(240+nsamples*4);

hdi_location = zeros(total_traces,1, 'uint64');
hdi_ffid = zeros(total_traces,1, 'uint32');
hdi_cdp = zeros(total_traces,1, 'uint32');
hdi_sx = zeros(total_traces,1, 'single');
hdi_sy = zeros(total_traces,1, 'single');
hdi_rx = zeros(total_traces,1, 'single');
hdi_ry = zeros(total_traces,1, 'single');
hdi_offset = zeros(total_traces,1, 'single');
hdi_aoffset = zeros(total_traces,1, 'single');
hdi_inline = zeros(total_traces,1, 'uint32');
hdi_xline = zeros(total_traces,1, 'uint32');
hdi_trace = zeros(total_traces,1, 'uint32');

fseek(fid1, 3600, 'bof'); 
for ntrace = 1:1:total_traces

    sgyhead_1bytes = fread(fid1,240,'uint8');
    fseek(fid1, -240, 'cof'); 
    sgyhead_2bytes = fread(fid1,120,'uint16');
    fseek(fid1, -240, 'cof'); 
    sgyhead_4bytes = fread(fid1,60,'int32');

    hdi_location(ntrace) = ftell(fid1)-240;
    hdi_trace(ntrace) = sgyhead_4bytes(1);
    hdi_ffid(ntrace) = sgyhead_4bytes(3);
    hdi_cdp(ntrace) = sgyhead_4bytes(6);
    hdi_aoffset(ntrace) = sgyhead_4bytes(10);
    hdi_inline(ntrace) = sgyhead_4bytes(48);
    hdi_xline(ntrace) = sgyhead_4bytes(49);

    if(sgyhead_2bytes(36) > 0)
    hdi_sx(ntrace) = sgyhead_4bytes(19)*sgyhead_2bytes(36);
    hdi_sy(ntrace) = sgyhead_4bytes(20)*sgyhead_2bytes(36);
    hdi_rx(ntrace) = sgyhead_4bytes(21)*sgyhead_2bytes(36);
    hdi_ry(ntrace) = sgyhead_4bytes(22)*sgyhead_2bytes(36);
    end

    if(sgyhead_2bytes() < 0)
    hdi_sx(ntrace) = sgyhead_4bytes(19)/sgyhead_2bytes(36);
    hdi_sy(ntrace) = sgyhead_4bytes(20)/sgyhead_2bytes(36);
    hdi_rx(ntrace) = sgyhead_4bytes(21)/sgyhead_2bytes(36);
    hdi_ry(ntrace) = sgyhead_4bytes(22)/sgyhead_2bytes(36);
    end
    
    fseek(fid1,nsamples*4,'cof');

end

fclose(fid1);
toc;

% hdi_aoffset=abs( (hdi_sx + 1i*hdi_sy ) - (hdi_rx + 1i*hdi_ry )) ;
% hdi_offset=sign( hdi_rx  -  hdi_sx ).*hdi_aoffset ;
hdi_offset=hdi_aoffset;

eval(['save ',hdi_filename,' hdi_ffid hdi_trace hdi_location hdi_cdp hdi_sx hdi_sy hdi_rx hdi_ry hdi_aoffset hdi_offset hdi_nsamples hdi_dt hdi_inline hdi_xline ']) ;
status=0 ;
return;


